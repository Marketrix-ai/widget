(function(O,g){typeof exports=="object"&&typeof module<"u"?g(exports,require("react"),require("react-dom")):typeof define=="function"&&define.amd?define(["exports","react","react-dom"],g):(O=typeof globalThis<"u"?globalThis:O||self,g(O.MarketrixInApp={},O.React,O.ReactDOM))})(this,function(O,g,K){"use strict";var en=Object.defineProperty;var tn=(O,g,K)=>g in O?en(O,g,{enumerable:!0,configurable:!0,writable:!0,value:K}):O[g]=K;var j=(O,g,K)=>tn(O,typeof g!="symbol"?g+"":g,K);var Ue={exports:{}},ae={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Kt=g,Gt=Symbol.for("react.element"),_t=Symbol.for("react.fragment"),Jt=Object.prototype.hasOwnProperty,Qt=Kt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,Zt={key:!0,ref:!0,__self:!0,__source:!0};function He(t,e,r){var o,n={},s=null,i=null;r!==void 0&&(s=""+r),e.key!==void 0&&(s=""+e.key),e.ref!==void 0&&(i=e.ref);for(o in e)Jt.call(e,o)&&!Zt.hasOwnProperty(o)&&(n[o]=e[o]);if(t&&t.defaultProps)for(o in e=t.defaultProps,e)n[o]===void 0&&(n[o]=e[o]);return{$$typeof:Gt,type:t,key:s,ref:i,props:n,_owner:Qt.current}}ae.Fragment=_t,ae.jsx=He,ae.jsxs=He,Ue.exports=ae;var d=Ue.exports,Xe,Ve=K;Xe=Ve.createRoot,Ve.hydrateRoot;function Ye(t,e){return function(){return t.apply(e,arguments)}}const{toString:$t}=Object.prototype,{getPrototypeOf:Se}=Object,{iterator:le,toStringTag:Ke}=Symbol,ce=(t=>e=>{const r=$t.call(e);return t[r]||(t[r]=r.slice(8,-1).toLowerCase())})(Object.create(null)),D=t=>(t=t.toLowerCase(),e=>ce(e)===t),de=t=>e=>typeof e===t,{isArray:G}=Array,J=de("undefined");function Q(t){return t!==null&&!J(t)&&t.constructor!==null&&!J(t.constructor)&&R(t.constructor.isBuffer)&&t.constructor.isBuffer(t)}const Ge=D("ArrayBuffer");function er(t){let e;return typeof ArrayBuffer<"u"&&ArrayBuffer.isView?e=ArrayBuffer.isView(t):e=t&&t.buffer&&Ge(t.buffer),e}const tr=de("string"),R=de("function"),_e=de("number"),Z=t=>t!==null&&typeof t=="object",rr=t=>t===!0||t===!1,ue=t=>{if(ce(t)!=="object")return!1;const e=Se(t);return(e===null||e===Object.prototype||Object.getPrototypeOf(e)===null)&&!(Ke in t)&&!(le in t)},or=t=>{if(!Z(t)||Q(t))return!1;try{return Object.keys(t).length===0&&Object.getPrototypeOf(t)===Object.prototype}catch{return!1}},nr=D("Date"),sr=D("File"),ir=D("Blob"),ar=D("FileList"),lr=t=>Z(t)&&R(t.pipe),cr=t=>{let e;return t&&(typeof FormData=="function"&&t instanceof FormData||R(t.append)&&((e=ce(t))==="formdata"||e==="object"&&R(t.toString)&&t.toString()==="[object FormData]"))},dr=D("URLSearchParams"),[ur,pr,hr,fr]=["ReadableStream","Request","Response","Headers"].map(D),mr=t=>t.trim?t.trim():t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,"");function $(t,e,{allOwnKeys:r=!1}={}){if(t===null||typeof t>"u")return;let o,n;if(typeof t!="object"&&(t=[t]),G(t))for(o=0,n=t.length;o<n;o++)e.call(null,t[o],o,t);else{if(Q(t))return;const s=r?Object.getOwnPropertyNames(t):Object.keys(t),i=s.length;let a;for(o=0;o<i;o++)a=s[o],e.call(null,t[a],a,t)}}function Je(t,e){if(Q(t))return null;e=e.toLowerCase();const r=Object.keys(t);let o=r.length,n;for(;o-- >0;)if(n=r[o],e===n.toLowerCase())return n;return null}const U=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:global,Qe=t=>!J(t)&&t!==U;function Ae(){const{caseless:t}=Qe(this)&&this||{},e={},r=(o,n)=>{const s=t&&Je(e,n)||n;ue(e[s])&&ue(o)?e[s]=Ae(e[s],o):ue(o)?e[s]=Ae({},o):G(o)?e[s]=o.slice():e[s]=o};for(let o=0,n=arguments.length;o<n;o++)arguments[o]&&$(arguments[o],r);return e}const gr=(t,e,r,{allOwnKeys:o}={})=>($(e,(n,s)=>{r&&R(n)?t[s]=Ye(n,r):t[s]=n},{allOwnKeys:o}),t),yr=t=>(t.charCodeAt(0)===65279&&(t=t.slice(1)),t),br=(t,e,r,o)=>{t.prototype=Object.create(e.prototype,o),t.prototype.constructor=t,Object.defineProperty(t,"super",{value:e.prototype}),r&&Object.assign(t.prototype,r)},xr=(t,e,r,o)=>{let n,s,i;const a={};if(e=e||{},t==null)return e;do{for(n=Object.getOwnPropertyNames(t),s=n.length;s-- >0;)i=n[s],(!o||o(i,t,e))&&!a[i]&&(e[i]=t[i],a[i]=!0);t=r!==!1&&Se(t)}while(t&&(!r||r(t,e))&&t!==Object.prototype);return e},wr=(t,e,r)=>{t=String(t),(r===void 0||r>t.length)&&(r=t.length),r-=e.length;const o=t.indexOf(e,r);return o!==-1&&o===r},vr=t=>{if(!t)return null;if(G(t))return t;let e=t.length;if(!_e(e))return null;const r=new Array(e);for(;e-- >0;)r[e]=t[e];return r},kr=(t=>e=>t&&e instanceof t)(typeof Uint8Array<"u"&&Se(Uint8Array)),Sr=(t,e)=>{const o=(t&&t[le]).call(t);let n;for(;(n=o.next())&&!n.done;){const s=n.value;e.call(t,s[0],s[1])}},Ar=(t,e)=>{let r;const o=[];for(;(r=t.exec(e))!==null;)o.push(r);return o},Er=D("HTMLFormElement"),Cr=t=>t.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g,function(r,o,n){return o.toUpperCase()+n}),Ze=(({hasOwnProperty:t})=>(e,r)=>t.call(e,r))(Object.prototype),Ir=D("RegExp"),$e=(t,e)=>{const r=Object.getOwnPropertyDescriptors(t),o={};$(r,(n,s)=>{let i;(i=e(n,s,t))!==!1&&(o[s]=i||n)}),Object.defineProperties(t,o)},Tr=t=>{$e(t,(e,r)=>{if(R(t)&&["arguments","caller","callee"].indexOf(r)!==-1)return!1;const o=t[r];if(R(o)){if(e.enumerable=!1,"writable"in e){e.writable=!1;return}e.set||(e.set=()=>{throw Error("Can not rewrite read-only method '"+r+"'")})}})},Nr=(t,e)=>{const r={},o=n=>{n.forEach(s=>{r[s]=!0})};return G(t)?o(t):o(String(t).split(e)),r},Pr=()=>{},jr=(t,e)=>t!=null&&Number.isFinite(t=+t)?t:e;function Or(t){return!!(t&&R(t.append)&&t[Ke]==="FormData"&&t[le])}const Lr=t=>{const e=new Array(10),r=(o,n)=>{if(Z(o)){if(e.indexOf(o)>=0)return;if(Q(o))return o;if(!("toJSON"in o)){e[n]=o;const s=G(o)?[]:{};return $(o,(i,a)=>{const p=r(i,n+1);!J(p)&&(s[a]=p)}),e[n]=void 0,s}}return o};return r(t,0)},Br=D("AsyncFunction"),zr=t=>t&&(Z(t)||R(t))&&R(t.then)&&R(t.catch),et=((t,e)=>t?setImmediate:e?((r,o)=>(U.addEventListener("message",({source:n,data:s})=>{n===U&&s===r&&o.length&&o.shift()()},!1),n=>{o.push(n),U.postMessage(r,"*")}))(`axios@${Math.random()}`,[]):r=>setTimeout(r))(typeof setImmediate=="function",R(U.postMessage)),Rr=typeof queueMicrotask<"u"?queueMicrotask.bind(U):typeof process<"u"&&process.nextTick||et,l={isArray:G,isArrayBuffer:Ge,isBuffer:Q,isFormData:cr,isArrayBufferView:er,isString:tr,isNumber:_e,isBoolean:rr,isObject:Z,isPlainObject:ue,isEmptyObject:or,isReadableStream:ur,isRequest:pr,isResponse:hr,isHeaders:fr,isUndefined:J,isDate:nr,isFile:sr,isBlob:ir,isRegExp:Ir,isFunction:R,isStream:lr,isURLSearchParams:dr,isTypedArray:kr,isFileList:ar,forEach:$,merge:Ae,extend:gr,trim:mr,stripBOM:yr,inherits:br,toFlatObject:xr,kindOf:ce,kindOfTest:D,endsWith:wr,toArray:vr,forEachEntry:Sr,matchAll:Ar,isHTMLForm:Er,hasOwnProperty:Ze,hasOwnProp:Ze,reduceDescriptors:$e,freezeMethods:Tr,toObjectSet:Nr,toCamelCase:Cr,noop:Pr,toFiniteNumber:jr,findKey:Je,global:U,isContextDefined:Qe,isSpecCompliantForm:Or,toJSONObject:Lr,isAsyncFn:Br,isThenable:zr,setImmediate:et,asap:Rr,isIterable:t=>t!=null&&R(t[le])};function S(t,e,r,o,n){Error.call(this),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=new Error().stack,this.message=t,this.name="AxiosError",e&&(this.code=e),r&&(this.config=r),o&&(this.request=o),n&&(this.response=n,this.status=n.status?n.status:null)}l.inherits(S,Error,{toJSON:function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:l.toJSONObject(this.config),code:this.code,status:this.status}}});const tt=S.prototype,rt={};["ERR_BAD_OPTION_VALUE","ERR_BAD_OPTION","ECONNABORTED","ETIMEDOUT","ERR_NETWORK","ERR_FR_TOO_MANY_REDIRECTS","ERR_DEPRECATED","ERR_BAD_RESPONSE","ERR_BAD_REQUEST","ERR_CANCELED","ERR_NOT_SUPPORT","ERR_INVALID_URL"].forEach(t=>{rt[t]={value:t}}),Object.defineProperties(S,rt),Object.defineProperty(tt,"isAxiosError",{value:!0}),S.from=(t,e,r,o,n,s)=>{const i=Object.create(tt);return l.toFlatObject(t,i,function(p){return p!==Error.prototype},a=>a!=="isAxiosError"),S.call(i,t.message,e,r,o,n),i.cause=t,i.name=t.name,s&&Object.assign(i,s),i};const Mr=null;function Ee(t){return l.isPlainObject(t)||l.isArray(t)}function ot(t){return l.endsWith(t,"[]")?t.slice(0,-2):t}function nt(t,e,r){return t?t.concat(e).map(function(n,s){return n=ot(n),!r&&s?"["+n+"]":n}).join(r?".":""):e}function Dr(t){return l.isArray(t)&&!t.some(Ee)}const Fr=l.toFlatObject(l,{},null,function(e){return/^is[A-Z]/.test(e)});function pe(t,e,r){if(!l.isObject(t))throw new TypeError("target must be an object");e=e||new FormData,r=l.toFlatObject(r,{metaTokens:!0,dots:!1,indexes:!1},!1,function(b,h){return!l.isUndefined(h[b])});const o=r.metaTokens,n=r.visitor||u,s=r.dots,i=r.indexes,p=(r.Blob||typeof Blob<"u"&&Blob)&&l.isSpecCompliantForm(e);if(!l.isFunction(n))throw new TypeError("visitor must be a function");function c(m){if(m===null)return"";if(l.isDate(m))return m.toISOString();if(l.isBoolean(m))return m.toString();if(!p&&l.isBlob(m))throw new S("Blob is not supported. Use a Buffer instead.");return l.isArrayBuffer(m)||l.isTypedArray(m)?p&&typeof Blob=="function"?new Blob([m]):Buffer.from(m):m}function u(m,b,h){let k=m;if(m&&!h&&typeof m=="object"){if(l.endsWith(b,"{}"))b=o?b:b.slice(0,-2),m=JSON.stringify(m);else if(l.isArray(m)&&Dr(m)||(l.isFileList(m)||l.endsWith(b,"[]"))&&(k=l.toArray(m)))return b=ot(b),k.forEach(function(v,N){!(l.isUndefined(v)||v===null)&&e.append(i===!0?nt([b],N,s):i===null?b:b+"[]",c(v))}),!1}return Ee(m)?!0:(e.append(nt(h,b,s),c(m)),!1)}const f=[],y=Object.assign(Fr,{defaultVisitor:u,convertValue:c,isVisitable:Ee});function x(m,b){if(!l.isUndefined(m)){if(f.indexOf(m)!==-1)throw Error("Circular reference detected in "+b.join("."));f.push(m),l.forEach(m,function(k,w){(!(l.isUndefined(k)||k===null)&&n.call(e,k,l.isString(w)?w.trim():w,b,y))===!0&&x(k,b?b.concat(w):[w])}),f.pop()}}if(!l.isObject(t))throw new TypeError("data must be an object");return x(t),e}function st(t){const e={"!":"%21","'":"%27","(":"%28",")":"%29","~":"%7E","%20":"+","%00":"\0"};return encodeURIComponent(t).replace(/[!'()~]|%20|%00/g,function(o){return e[o]})}function Ce(t,e){this._pairs=[],t&&pe(t,this,e)}const it=Ce.prototype;it.append=function(e,r){this._pairs.push([e,r])},it.toString=function(e){const r=e?function(o){return e.call(this,o,st)}:st;return this._pairs.map(function(n){return r(n[0])+"="+r(n[1])},"").join("&")};function qr(t){return encodeURIComponent(t).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}function at(t,e,r){if(!e)return t;const o=r&&r.encode||qr;l.isFunction(r)&&(r={serialize:r});const n=r&&r.serialize;let s;if(n?s=n(e,r):s=l.isURLSearchParams(e)?e.toString():new Ce(e,r).toString(o),s){const i=t.indexOf("#");i!==-1&&(t=t.slice(0,i)),t+=(t.indexOf("?")===-1?"?":"&")+s}return t}class lt{constructor(){this.handlers=[]}use(e,r,o){return this.handlers.push({fulfilled:e,rejected:r,synchronous:o?o.synchronous:!1,runWhen:o?o.runWhen:null}),this.handlers.length-1}eject(e){this.handlers[e]&&(this.handlers[e]=null)}clear(){this.handlers&&(this.handlers=[])}forEach(e){l.forEach(this.handlers,function(o){o!==null&&e(o)})}}const ct={silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1},Wr={isBrowser:!0,classes:{URLSearchParams:typeof URLSearchParams<"u"?URLSearchParams:Ce,FormData:typeof FormData<"u"?FormData:null,Blob:typeof Blob<"u"?Blob:null},protocols:["http","https","file","blob","url","data"]},Ie=typeof window<"u"&&typeof document<"u",Te=typeof navigator=="object"&&navigator||void 0,Ur=Ie&&(!Te||["ReactNative","NativeScript","NS"].indexOf(Te.product)<0),Hr=typeof WorkerGlobalScope<"u"&&self instanceof WorkerGlobalScope&&typeof self.importScripts=="function",Xr=Ie&&window.location.href||"http://localhost",B={...Object.freeze(Object.defineProperty({__proto__:null,hasBrowserEnv:Ie,hasStandardBrowserEnv:Ur,hasStandardBrowserWebWorkerEnv:Hr,navigator:Te,origin:Xr},Symbol.toStringTag,{value:"Module"})),...Wr};function Vr(t,e){return pe(t,new B.classes.URLSearchParams,{visitor:function(r,o,n,s){return B.isNode&&l.isBuffer(r)?(this.append(o,r.toString("base64")),!1):s.defaultVisitor.apply(this,arguments)},...e})}function Yr(t){return l.matchAll(/\w+|\[(\w*)]/g,t).map(e=>e[0]==="[]"?"":e[1]||e[0])}function Kr(t){const e={},r=Object.keys(t);let o;const n=r.length;let s;for(o=0;o<n;o++)s=r[o],e[s]=t[s];return e}function dt(t){function e(r,o,n,s){let i=r[s++];if(i==="__proto__")return!0;const a=Number.isFinite(+i),p=s>=r.length;return i=!i&&l.isArray(n)?n.length:i,p?(l.hasOwnProp(n,i)?n[i]=[n[i],o]:n[i]=o,!a):((!n[i]||!l.isObject(n[i]))&&(n[i]=[]),e(r,o,n[i],s)&&l.isArray(n[i])&&(n[i]=Kr(n[i])),!a)}if(l.isFormData(t)&&l.isFunction(t.entries)){const r={};return l.forEachEntry(t,(o,n)=>{e(Yr(o),n,r,0)}),r}return null}function Gr(t,e,r){if(l.isString(t))try{return(e||JSON.parse)(t),l.trim(t)}catch(o){if(o.name!=="SyntaxError")throw o}return(r||JSON.stringify)(t)}const ee={transitional:ct,adapter:["xhr","http","fetch"],transformRequest:[function(e,r){const o=r.getContentType()||"",n=o.indexOf("application/json")>-1,s=l.isObject(e);if(s&&l.isHTMLForm(e)&&(e=new FormData(e)),l.isFormData(e))return n?JSON.stringify(dt(e)):e;if(l.isArrayBuffer(e)||l.isBuffer(e)||l.isStream(e)||l.isFile(e)||l.isBlob(e)||l.isReadableStream(e))return e;if(l.isArrayBufferView(e))return e.buffer;if(l.isURLSearchParams(e))return r.setContentType("application/x-www-form-urlencoded;charset=utf-8",!1),e.toString();let a;if(s){if(o.indexOf("application/x-www-form-urlencoded")>-1)return Vr(e,this.formSerializer).toString();if((a=l.isFileList(e))||o.indexOf("multipart/form-data")>-1){const p=this.env&&this.env.FormData;return pe(a?{"files[]":e}:e,p&&new p,this.formSerializer)}}return s||n?(r.setContentType("application/json",!1),Gr(e)):e}],transformResponse:[function(e){const r=this.transitional||ee.transitional,o=r&&r.forcedJSONParsing,n=this.responseType==="json";if(l.isResponse(e)||l.isReadableStream(e))return e;if(e&&l.isString(e)&&(o&&!this.responseType||n)){const i=!(r&&r.silentJSONParsing)&&n;try{return JSON.parse(e)}catch(a){if(i)throw a.name==="SyntaxError"?S.from(a,S.ERR_BAD_RESPONSE,this,null,this.response):a}}return e}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,env:{FormData:B.classes.FormData,Blob:B.classes.Blob},validateStatus:function(e){return e>=200&&e<300},headers:{common:{Accept:"application/json, text/plain, */*","Content-Type":void 0}}};l.forEach(["delete","get","head","post","put","patch"],t=>{ee.headers[t]={}});const _r=l.toObjectSet(["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"]),Jr=t=>{const e={};let r,o,n;return t&&t.split(`
`).forEach(function(i){n=i.indexOf(":"),r=i.substring(0,n).trim().toLowerCase(),o=i.substring(n+1).trim(),!(!r||e[r]&&_r[r])&&(r==="set-cookie"?e[r]?e[r].push(o):e[r]=[o]:e[r]=e[r]?e[r]+", "+o:o)}),e},ut=Symbol("internals");function te(t){return t&&String(t).trim().toLowerCase()}function he(t){return t===!1||t==null?t:l.isArray(t)?t.map(he):String(t)}function Qr(t){const e=Object.create(null),r=/([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;let o;for(;o=r.exec(t);)e[o[1]]=o[2];return e}const Zr=t=>/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(t.trim());function Ne(t,e,r,o,n){if(l.isFunction(o))return o.call(this,e,r);if(n&&(e=r),!!l.isString(e)){if(l.isString(o))return e.indexOf(o)!==-1;if(l.isRegExp(o))return o.test(e)}}function $r(t){return t.trim().toLowerCase().replace(/([a-z\d])(\w*)/g,(e,r,o)=>r.toUpperCase()+o)}function eo(t,e){const r=l.toCamelCase(" "+e);["get","set","has"].forEach(o=>{Object.defineProperty(t,o+r,{value:function(n,s,i){return this[o].call(this,e,n,s,i)},configurable:!0})})}let M=class{constructor(e){e&&this.set(e)}set(e,r,o){const n=this;function s(a,p,c){const u=te(p);if(!u)throw new Error("header name must be a non-empty string");const f=l.findKey(n,u);(!f||n[f]===void 0||c===!0||c===void 0&&n[f]!==!1)&&(n[f||p]=he(a))}const i=(a,p)=>l.forEach(a,(c,u)=>s(c,u,p));if(l.isPlainObject(e)||e instanceof this.constructor)i(e,r);else if(l.isString(e)&&(e=e.trim())&&!Zr(e))i(Jr(e),r);else if(l.isObject(e)&&l.isIterable(e)){let a={},p,c;for(const u of e){if(!l.isArray(u))throw TypeError("Object iterator must return a key-value pair");a[c=u[0]]=(p=a[c])?l.isArray(p)?[...p,u[1]]:[p,u[1]]:u[1]}i(a,r)}else e!=null&&s(r,e,o);return this}get(e,r){if(e=te(e),e){const o=l.findKey(this,e);if(o){const n=this[o];if(!r)return n;if(r===!0)return Qr(n);if(l.isFunction(r))return r.call(this,n,o);if(l.isRegExp(r))return r.exec(n);throw new TypeError("parser must be boolean|regexp|function")}}}has(e,r){if(e=te(e),e){const o=l.findKey(this,e);return!!(o&&this[o]!==void 0&&(!r||Ne(this,this[o],o,r)))}return!1}delete(e,r){const o=this;let n=!1;function s(i){if(i=te(i),i){const a=l.findKey(o,i);a&&(!r||Ne(o,o[a],a,r))&&(delete o[a],n=!0)}}return l.isArray(e)?e.forEach(s):s(e),n}clear(e){const r=Object.keys(this);let o=r.length,n=!1;for(;o--;){const s=r[o];(!e||Ne(this,this[s],s,e,!0))&&(delete this[s],n=!0)}return n}normalize(e){const r=this,o={};return l.forEach(this,(n,s)=>{const i=l.findKey(o,s);if(i){r[i]=he(n),delete r[s];return}const a=e?$r(s):String(s).trim();a!==s&&delete r[s],r[a]=he(n),o[a]=!0}),this}concat(...e){return this.constructor.concat(this,...e)}toJSON(e){const r=Object.create(null);return l.forEach(this,(o,n)=>{o!=null&&o!==!1&&(r[n]=e&&l.isArray(o)?o.join(", "):o)}),r}[Symbol.iterator](){return Object.entries(this.toJSON())[Symbol.iterator]()}toString(){return Object.entries(this.toJSON()).map(([e,r])=>e+": "+r).join(`
`)}getSetCookie(){return this.get("set-cookie")||[]}get[Symbol.toStringTag](){return"AxiosHeaders"}static from(e){return e instanceof this?e:new this(e)}static concat(e,...r){const o=new this(e);return r.forEach(n=>o.set(n)),o}static accessor(e){const o=(this[ut]=this[ut]={accessors:{}}).accessors,n=this.prototype;function s(i){const a=te(i);o[a]||(eo(n,i),o[a]=!0)}return l.isArray(e)?e.forEach(s):s(e),this}};M.accessor(["Content-Type","Content-Length","Accept","Accept-Encoding","User-Agent","Authorization"]),l.reduceDescriptors(M.prototype,({value:t},e)=>{let r=e[0].toUpperCase()+e.slice(1);return{get:()=>t,set(o){this[r]=o}}}),l.freezeMethods(M);function Pe(t,e){const r=this||ee,o=e||r,n=M.from(o.headers);let s=o.data;return l.forEach(t,function(a){s=a.call(r,s,n.normalize(),e?e.status:void 0)}),n.normalize(),s}function pt(t){return!!(t&&t.__CANCEL__)}function _(t,e,r){S.call(this,t??"canceled",S.ERR_CANCELED,e,r),this.name="CanceledError"}l.inherits(_,S,{__CANCEL__:!0});function ht(t,e,r){const o=r.config.validateStatus;!r.status||!o||o(r.status)?t(r):e(new S("Request failed with status code "+r.status,[S.ERR_BAD_REQUEST,S.ERR_BAD_RESPONSE][Math.floor(r.status/100)-4],r.config,r.request,r))}function to(t){const e=/^([-+\w]{1,25})(:?\/\/|:)/.exec(t);return e&&e[1]||""}function ro(t,e){t=t||10;const r=new Array(t),o=new Array(t);let n=0,s=0,i;return e=e!==void 0?e:1e3,function(p){const c=Date.now(),u=o[s];i||(i=c),r[n]=p,o[n]=c;let f=s,y=0;for(;f!==n;)y+=r[f++],f=f%t;if(n=(n+1)%t,n===s&&(s=(s+1)%t),c-i<e)return;const x=u&&c-u;return x?Math.round(y*1e3/x):void 0}}function oo(t,e){let r=0,o=1e3/e,n,s;const i=(c,u=Date.now())=>{r=u,n=null,s&&(clearTimeout(s),s=null),t(...c)};return[(...c)=>{const u=Date.now(),f=u-r;f>=o?i(c,u):(n=c,s||(s=setTimeout(()=>{s=null,i(n)},o-f)))},()=>n&&i(n)]}const fe=(t,e,r=3)=>{let o=0;const n=ro(50,250);return oo(s=>{const i=s.loaded,a=s.lengthComputable?s.total:void 0,p=i-o,c=n(p),u=i<=a;o=i;const f={loaded:i,total:a,progress:a?i/a:void 0,bytes:p,rate:c||void 0,estimated:c&&a&&u?(a-i)/c:void 0,event:s,lengthComputable:a!=null,[e?"download":"upload"]:!0};t(f)},r)},ft=(t,e)=>{const r=t!=null;return[o=>e[0]({lengthComputable:r,total:t,loaded:o}),e[1]]},mt=t=>(...e)=>l.asap(()=>t(...e)),no=B.hasStandardBrowserEnv?((t,e)=>r=>(r=new URL(r,B.origin),t.protocol===r.protocol&&t.host===r.host&&(e||t.port===r.port)))(new URL(B.origin),B.navigator&&/(msie|trident)/i.test(B.navigator.userAgent)):()=>!0,so=B.hasStandardBrowserEnv?{write(t,e,r,o,n,s){const i=[t+"="+encodeURIComponent(e)];l.isNumber(r)&&i.push("expires="+new Date(r).toGMTString()),l.isString(o)&&i.push("path="+o),l.isString(n)&&i.push("domain="+n),s===!0&&i.push("secure"),document.cookie=i.join("; ")},read(t){const e=document.cookie.match(new RegExp("(^|;\\s*)("+t+")=([^;]*)"));return e?decodeURIComponent(e[3]):null},remove(t){this.write(t,"",Date.now()-864e5)}}:{write(){},read(){return null},remove(){}};function io(t){return/^([a-z][a-z\d+\-.]*:)?\/\//i.test(t)}function ao(t,e){return e?t.replace(/\/?\/$/,"")+"/"+e.replace(/^\/+/,""):t}function gt(t,e,r){let o=!io(e);return t&&(o||r==!1)?ao(t,e):e}const yt=t=>t instanceof M?{...t}:t;function H(t,e){e=e||{};const r={};function o(c,u,f,y){return l.isPlainObject(c)&&l.isPlainObject(u)?l.merge.call({caseless:y},c,u):l.isPlainObject(u)?l.merge({},u):l.isArray(u)?u.slice():u}function n(c,u,f,y){if(l.isUndefined(u)){if(!l.isUndefined(c))return o(void 0,c,f,y)}else return o(c,u,f,y)}function s(c,u){if(!l.isUndefined(u))return o(void 0,u)}function i(c,u){if(l.isUndefined(u)){if(!l.isUndefined(c))return o(void 0,c)}else return o(void 0,u)}function a(c,u,f){if(f in e)return o(c,u);if(f in t)return o(void 0,c)}const p={url:s,method:s,data:s,baseURL:i,transformRequest:i,transformResponse:i,paramsSerializer:i,timeout:i,timeoutMessage:i,withCredentials:i,withXSRFToken:i,adapter:i,responseType:i,xsrfCookieName:i,xsrfHeaderName:i,onUploadProgress:i,onDownloadProgress:i,decompress:i,maxContentLength:i,maxBodyLength:i,beforeRedirect:i,transport:i,httpAgent:i,httpsAgent:i,cancelToken:i,socketPath:i,responseEncoding:i,validateStatus:a,headers:(c,u,f)=>n(yt(c),yt(u),f,!0)};return l.forEach(Object.keys({...t,...e}),function(u){const f=p[u]||n,y=f(t[u],e[u],u);l.isUndefined(y)&&f!==a||(r[u]=y)}),r}const bt=t=>{const e=H({},t);let{data:r,withXSRFToken:o,xsrfHeaderName:n,xsrfCookieName:s,headers:i,auth:a}=e;e.headers=i=M.from(i),e.url=at(gt(e.baseURL,e.url,e.allowAbsoluteUrls),t.params,t.paramsSerializer),a&&i.set("Authorization","Basic "+btoa((a.username||"")+":"+(a.password?unescape(encodeURIComponent(a.password)):"")));let p;if(l.isFormData(r)){if(B.hasStandardBrowserEnv||B.hasStandardBrowserWebWorkerEnv)i.setContentType(void 0);else if((p=i.getContentType())!==!1){const[c,...u]=p?p.split(";").map(f=>f.trim()).filter(Boolean):[];i.setContentType([c||"multipart/form-data",...u].join("; "))}}if(B.hasStandardBrowserEnv&&(o&&l.isFunction(o)&&(o=o(e)),o||o!==!1&&no(e.url))){const c=n&&s&&so.read(s);c&&i.set(n,c)}return e},lo=typeof XMLHttpRequest<"u"&&function(t){return new Promise(function(r,o){const n=bt(t);let s=n.data;const i=M.from(n.headers).normalize();let{responseType:a,onUploadProgress:p,onDownloadProgress:c}=n,u,f,y,x,m;function b(){x&&x(),m&&m(),n.cancelToken&&n.cancelToken.unsubscribe(u),n.signal&&n.signal.removeEventListener("abort",u)}let h=new XMLHttpRequest;h.open(n.method.toUpperCase(),n.url,!0),h.timeout=n.timeout;function k(){if(!h)return;const v=M.from("getAllResponseHeaders"in h&&h.getAllResponseHeaders()),A={data:!a||a==="text"||a==="json"?h.responseText:h.response,status:h.status,statusText:h.statusText,headers:v,config:t,request:h};ht(function(E){r(E),b()},function(E){o(E),b()},A),h=null}"onloadend"in h?h.onloadend=k:h.onreadystatechange=function(){!h||h.readyState!==4||h.status===0&&!(h.responseURL&&h.responseURL.indexOf("file:")===0)||setTimeout(k)},h.onabort=function(){h&&(o(new S("Request aborted",S.ECONNABORTED,t,h)),h=null)},h.onerror=function(){o(new S("Network Error",S.ERR_NETWORK,t,h)),h=null},h.ontimeout=function(){let N=n.timeout?"timeout of "+n.timeout+"ms exceeded":"timeout exceeded";const A=n.transitional||ct;n.timeoutErrorMessage&&(N=n.timeoutErrorMessage),o(new S(N,A.clarifyTimeoutError?S.ETIMEDOUT:S.ECONNABORTED,t,h)),h=null},s===void 0&&i.setContentType(null),"setRequestHeader"in h&&l.forEach(i.toJSON(),function(N,A){h.setRequestHeader(A,N)}),l.isUndefined(n.withCredentials)||(h.withCredentials=!!n.withCredentials),a&&a!=="json"&&(h.responseType=n.responseType),c&&([y,m]=fe(c,!0),h.addEventListener("progress",y)),p&&h.upload&&([f,x]=fe(p),h.upload.addEventListener("progress",f),h.upload.addEventListener("loadend",x)),(n.cancelToken||n.signal)&&(u=v=>{h&&(o(!v||v.type?new _(null,t,h):v),h.abort(),h=null)},n.cancelToken&&n.cancelToken.subscribe(u),n.signal&&(n.signal.aborted?u():n.signal.addEventListener("abort",u)));const w=to(n.url);if(w&&B.protocols.indexOf(w)===-1){o(new S("Unsupported protocol "+w+":",S.ERR_BAD_REQUEST,t));return}h.send(s||null)})},co=(t,e)=>{const{length:r}=t=t?t.filter(Boolean):[];if(e||r){let o=new AbortController,n;const s=function(c){if(!n){n=!0,a();const u=c instanceof Error?c:this.reason;o.abort(u instanceof S?u:new _(u instanceof Error?u.message:u))}};let i=e&&setTimeout(()=>{i=null,s(new S(`timeout ${e} of ms exceeded`,S.ETIMEDOUT))},e);const a=()=>{t&&(i&&clearTimeout(i),i=null,t.forEach(c=>{c.unsubscribe?c.unsubscribe(s):c.removeEventListener("abort",s)}),t=null)};t.forEach(c=>c.addEventListener("abort",s));const{signal:p}=o;return p.unsubscribe=()=>l.asap(a),p}},uo=function*(t,e){let r=t.byteLength;if(r<e){yield t;return}let o=0,n;for(;o<r;)n=o+e,yield t.slice(o,n),o=n},po=async function*(t,e){for await(const r of ho(t))yield*uo(r,e)},ho=async function*(t){if(t[Symbol.asyncIterator]){yield*t;return}const e=t.getReader();try{for(;;){const{done:r,value:o}=await e.read();if(r)break;yield o}}finally{await e.cancel()}},xt=(t,e,r,o)=>{const n=po(t,e);let s=0,i,a=p=>{i||(i=!0,o&&o(p))};return new ReadableStream({async pull(p){try{const{done:c,value:u}=await n.next();if(c){a(),p.close();return}let f=u.byteLength;if(r){let y=s+=f;r(y)}p.enqueue(new Uint8Array(u))}catch(c){throw a(c),c}},cancel(p){return a(p),n.return()}},{highWaterMark:2})},me=typeof fetch=="function"&&typeof Request=="function"&&typeof Response=="function",wt=me&&typeof ReadableStream=="function",fo=me&&(typeof TextEncoder=="function"?(t=>e=>t.encode(e))(new TextEncoder):async t=>new Uint8Array(await new Response(t).arrayBuffer())),vt=(t,...e)=>{try{return!!t(...e)}catch{return!1}},mo=wt&&vt(()=>{let t=!1;const e=new Request(B.origin,{body:new ReadableStream,method:"POST",get duplex(){return t=!0,"half"}}).headers.has("Content-Type");return t&&!e}),kt=64*1024,je=wt&&vt(()=>l.isReadableStream(new Response("").body)),ge={stream:je&&(t=>t.body)};me&&(t=>{["text","arrayBuffer","blob","formData","stream"].forEach(e=>{!ge[e]&&(ge[e]=l.isFunction(t[e])?r=>r[e]():(r,o)=>{throw new S(`Response type '${e}' is not supported`,S.ERR_NOT_SUPPORT,o)})})})(new Response);const go=async t=>{if(t==null)return 0;if(l.isBlob(t))return t.size;if(l.isSpecCompliantForm(t))return(await new Request(B.origin,{method:"POST",body:t}).arrayBuffer()).byteLength;if(l.isArrayBufferView(t)||l.isArrayBuffer(t))return t.byteLength;if(l.isURLSearchParams(t)&&(t=t+""),l.isString(t))return(await fo(t)).byteLength},yo=async(t,e)=>{const r=l.toFiniteNumber(t.getContentLength());return r??go(e)},Oe={http:Mr,xhr:lo,fetch:me&&(async t=>{let{url:e,method:r,data:o,signal:n,cancelToken:s,timeout:i,onDownloadProgress:a,onUploadProgress:p,responseType:c,headers:u,withCredentials:f="same-origin",fetchOptions:y}=bt(t);c=c?(c+"").toLowerCase():"text";let x=co([n,s&&s.toAbortSignal()],i),m;const b=x&&x.unsubscribe&&(()=>{x.unsubscribe()});let h;try{if(p&&mo&&r!=="get"&&r!=="head"&&(h=await yo(u,o))!==0){let A=new Request(e,{method:"POST",body:o,duplex:"half"}),P;if(l.isFormData(o)&&(P=A.headers.get("content-type"))&&u.setContentType(P),A.body){const[E,q]=ft(h,fe(mt(p)));o=xt(A.body,kt,E,q)}}l.isString(f)||(f=f?"include":"omit");const k="credentials"in Request.prototype;m=new Request(e,{...y,signal:x,method:r.toUpperCase(),headers:u.normalize().toJSON(),body:o,duplex:"half",credentials:k?f:void 0});let w=await fetch(m,y);const v=je&&(c==="stream"||c==="response");if(je&&(a||v&&b)){const A={};["status","statusText","headers"].forEach(C=>{A[C]=w[C]});const P=l.toFiniteNumber(w.headers.get("content-length")),[E,q]=a&&ft(P,fe(mt(a),!0))||[];w=new Response(xt(w.body,kt,E,()=>{q&&q(),b&&b()}),A)}c=c||"text";let N=await ge[l.findKey(ge,c)||"text"](w,t);return!v&&b&&b(),await new Promise((A,P)=>{ht(A,P,{data:N,headers:M.from(w.headers),status:w.status,statusText:w.statusText,config:t,request:m})})}catch(k){throw b&&b(),k&&k.name==="TypeError"&&/Load failed|fetch/i.test(k.message)?Object.assign(new S("Network Error",S.ERR_NETWORK,t,m),{cause:k.cause||k}):S.from(k,k&&k.code,t,m)}})};l.forEach(Oe,(t,e)=>{if(t){try{Object.defineProperty(t,"name",{value:e})}catch{}Object.defineProperty(t,"adapterName",{value:e})}});const St=t=>`- ${t}`,bo=t=>l.isFunction(t)||t===null||t===!1,At={getAdapter:t=>{t=l.isArray(t)?t:[t];const{length:e}=t;let r,o;const n={};for(let s=0;s<e;s++){r=t[s];let i;if(o=r,!bo(r)&&(o=Oe[(i=String(r)).toLowerCase()],o===void 0))throw new S(`Unknown adapter '${i}'`);if(o)break;n[i||"#"+s]=o}if(!o){const s=Object.entries(n).map(([a,p])=>`adapter ${a} `+(p===!1?"is not supported by the environment":"is not available in the build"));let i=e?s.length>1?`since :
`+s.map(St).join(`
`):" "+St(s[0]):"as no adapter specified";throw new S("There is no suitable adapter to dispatch the request "+i,"ERR_NOT_SUPPORT")}return o},adapters:Oe};function Le(t){if(t.cancelToken&&t.cancelToken.throwIfRequested(),t.signal&&t.signal.aborted)throw new _(null,t)}function Et(t){return Le(t),t.headers=M.from(t.headers),t.data=Pe.call(t,t.transformRequest),["post","put","patch"].indexOf(t.method)!==-1&&t.headers.setContentType("application/x-www-form-urlencoded",!1),At.getAdapter(t.adapter||ee.adapter)(t).then(function(o){return Le(t),o.data=Pe.call(t,t.transformResponse,o),o.headers=M.from(o.headers),o},function(o){return pt(o)||(Le(t),o&&o.response&&(o.response.data=Pe.call(t,t.transformResponse,o.response),o.response.headers=M.from(o.response.headers))),Promise.reject(o)})}const Ct="1.11.0",ye={};["object","boolean","number","function","string","symbol"].forEach((t,e)=>{ye[t]=function(o){return typeof o===t||"a"+(e<1?"n ":" ")+t}});const It={};ye.transitional=function(e,r,o){function n(s,i){return"[Axios v"+Ct+"] Transitional option '"+s+"'"+i+(o?". "+o:"")}return(s,i,a)=>{if(e===!1)throw new S(n(i," has been removed"+(r?" in "+r:"")),S.ERR_DEPRECATED);return r&&!It[i]&&(It[i]=!0,console.warn(n(i," has been deprecated since v"+r+" and will be removed in the near future"))),e?e(s,i,a):!0}},ye.spelling=function(e){return(r,o)=>(console.warn(`${o} is likely a misspelling of ${e}`),!0)};function xo(t,e,r){if(typeof t!="object")throw new S("options must be an object",S.ERR_BAD_OPTION_VALUE);const o=Object.keys(t);let n=o.length;for(;n-- >0;){const s=o[n],i=e[s];if(i){const a=t[s],p=a===void 0||i(a,s,t);if(p!==!0)throw new S("option "+s+" must be "+p,S.ERR_BAD_OPTION_VALUE);continue}if(r!==!0)throw new S("Unknown option "+s,S.ERR_BAD_OPTION)}}const be={assertOptions:xo,validators:ye},F=be.validators;let X=class{constructor(e){this.defaults=e||{},this.interceptors={request:new lt,response:new lt}}async request(e,r){try{return await this._request(e,r)}catch(o){if(o instanceof Error){let n={};Error.captureStackTrace?Error.captureStackTrace(n):n=new Error;const s=n.stack?n.stack.replace(/^.+\n/,""):"";try{o.stack?s&&!String(o.stack).endsWith(s.replace(/^.+\n.+\n/,""))&&(o.stack+=`
`+s):o.stack=s}catch{}}throw o}}_request(e,r){typeof e=="string"?(r=r||{},r.url=e):r=e||{},r=H(this.defaults,r);const{transitional:o,paramsSerializer:n,headers:s}=r;o!==void 0&&be.assertOptions(o,{silentJSONParsing:F.transitional(F.boolean),forcedJSONParsing:F.transitional(F.boolean),clarifyTimeoutError:F.transitional(F.boolean)},!1),n!=null&&(l.isFunction(n)?r.paramsSerializer={serialize:n}:be.assertOptions(n,{encode:F.function,serialize:F.function},!0)),r.allowAbsoluteUrls!==void 0||(this.defaults.allowAbsoluteUrls!==void 0?r.allowAbsoluteUrls=this.defaults.allowAbsoluteUrls:r.allowAbsoluteUrls=!0),be.assertOptions(r,{baseUrl:F.spelling("baseURL"),withXsrfToken:F.spelling("withXSRFToken")},!0),r.method=(r.method||this.defaults.method||"get").toLowerCase();let i=s&&l.merge(s.common,s[r.method]);s&&l.forEach(["delete","get","head","post","put","patch","common"],m=>{delete s[m]}),r.headers=M.concat(i,s);const a=[];let p=!0;this.interceptors.request.forEach(function(b){typeof b.runWhen=="function"&&b.runWhen(r)===!1||(p=p&&b.synchronous,a.unshift(b.fulfilled,b.rejected))});const c=[];this.interceptors.response.forEach(function(b){c.push(b.fulfilled,b.rejected)});let u,f=0,y;if(!p){const m=[Et.bind(this),void 0];for(m.unshift(...a),m.push(...c),y=m.length,u=Promise.resolve(r);f<y;)u=u.then(m[f++],m[f++]);return u}y=a.length;let x=r;for(f=0;f<y;){const m=a[f++],b=a[f++];try{x=m(x)}catch(h){b.call(this,h);break}}try{u=Et.call(this,x)}catch(m){return Promise.reject(m)}for(f=0,y=c.length;f<y;)u=u.then(c[f++],c[f++]);return u}getUri(e){e=H(this.defaults,e);const r=gt(e.baseURL,e.url,e.allowAbsoluteUrls);return at(r,e.params,e.paramsSerializer)}};l.forEach(["delete","get","head","options"],function(e){X.prototype[e]=function(r,o){return this.request(H(o||{},{method:e,url:r,data:(o||{}).data}))}}),l.forEach(["post","put","patch"],function(e){function r(o){return function(s,i,a){return this.request(H(a||{},{method:e,headers:o?{"Content-Type":"multipart/form-data"}:{},url:s,data:i}))}}X.prototype[e]=r(),X.prototype[e+"Form"]=r(!0)});let wo=class Yt{constructor(e){if(typeof e!="function")throw new TypeError("executor must be a function.");let r;this.promise=new Promise(function(s){r=s});const o=this;this.promise.then(n=>{if(!o._listeners)return;let s=o._listeners.length;for(;s-- >0;)o._listeners[s](n);o._listeners=null}),this.promise.then=n=>{let s;const i=new Promise(a=>{o.subscribe(a),s=a}).then(n);return i.cancel=function(){o.unsubscribe(s)},i},e(function(s,i,a){o.reason||(o.reason=new _(s,i,a),r(o.reason))})}throwIfRequested(){if(this.reason)throw this.reason}subscribe(e){if(this.reason){e(this.reason);return}this._listeners?this._listeners.push(e):this._listeners=[e]}unsubscribe(e){if(!this._listeners)return;const r=this._listeners.indexOf(e);r!==-1&&this._listeners.splice(r,1)}toAbortSignal(){const e=new AbortController,r=o=>{e.abort(o)};return this.subscribe(r),e.signal.unsubscribe=()=>this.unsubscribe(r),e.signal}static source(){let e;return{token:new Yt(function(n){e=n}),cancel:e}}};function vo(t){return function(r){return t.apply(null,r)}}function ko(t){return l.isObject(t)&&t.isAxiosError===!0}const Be={Continue:100,SwitchingProtocols:101,Processing:102,EarlyHints:103,Ok:200,Created:201,Accepted:202,NonAuthoritativeInformation:203,NoContent:204,ResetContent:205,PartialContent:206,MultiStatus:207,AlreadyReported:208,ImUsed:226,MultipleChoices:300,MovedPermanently:301,Found:302,SeeOther:303,NotModified:304,UseProxy:305,Unused:306,TemporaryRedirect:307,PermanentRedirect:308,BadRequest:400,Unauthorized:401,PaymentRequired:402,Forbidden:403,NotFound:404,MethodNotAllowed:405,NotAcceptable:406,ProxyAuthenticationRequired:407,RequestTimeout:408,Conflict:409,Gone:410,LengthRequired:411,PreconditionFailed:412,PayloadTooLarge:413,UriTooLong:414,UnsupportedMediaType:415,RangeNotSatisfiable:416,ExpectationFailed:417,ImATeapot:418,MisdirectedRequest:421,UnprocessableEntity:422,Locked:423,FailedDependency:424,TooEarly:425,UpgradeRequired:426,PreconditionRequired:428,TooManyRequests:429,RequestHeaderFieldsTooLarge:431,UnavailableForLegalReasons:451,InternalServerError:500,NotImplemented:501,BadGateway:502,ServiceUnavailable:503,GatewayTimeout:504,HttpVersionNotSupported:505,VariantAlsoNegotiates:506,InsufficientStorage:507,LoopDetected:508,NotExtended:510,NetworkAuthenticationRequired:511};Object.entries(Be).forEach(([t,e])=>{Be[e]=t});function Tt(t){const e=new X(t),r=Ye(X.prototype.request,e);return l.extend(r,X.prototype,e,{allOwnKeys:!0}),l.extend(r,e,null,{allOwnKeys:!0}),r.create=function(n){return Tt(H(t,n))},r}const I=Tt(ee);I.Axios=X,I.CanceledError=_,I.CancelToken=wo,I.isCancel=pt,I.VERSION=Ct,I.toFormData=pe,I.AxiosError=S,I.Cancel=I.CanceledError,I.all=function(e){return Promise.all(e)},I.spread=vo,I.isAxiosError=ko,I.mergeConfig=H,I.AxiosHeaders=M,I.formToJSON=t=>dt(l.isHTMLForm(t)?new FormData(t):t),I.getAdapter=At.getAdapter,I.HttpStatusCode=Be,I.default=I;const{Axios:dn,AxiosError:un,CanceledError:pn,isCancel:hn,CancelToken:fn,VERSION:mn,all:gn,Cancel:yn,isAxiosError:bn,spread:xn,toFormData:wn,AxiosHeaders:vn,HttpStatusCode:kn,formToJSON:Sn,getAdapter:An,mergeConfig:En}=I;class So{constructor(e){j(this,"api");j(this,"config");this.config=e,this.api=I.create({baseURL:"https://api.marketrix.ai",timeout:3e4,headers:{"Content-Type":"application/json","X-Marketrix-ID":e.marketrixId,"X-Marketrix-Key":e.marketrixKey}}),this.api.interceptors.request.use(r=>(r.headers["X-Marketrix-ID"]=this.config.marketrixId,r.headers["X-Marketrix-Key"]=this.config.marketrixKey,r),r=>Promise.reject(r)),this.api.interceptors.response.use(r=>r,r=>(console.error("Marketrix API Error:",r),Promise.reject(r)))}async sendMessage(e,r){try{const o={message:e,mode:r,marketrixId:this.config.marketrixId,marketrixKey:this.config.marketrixKey},n=await this.api.post("/chat/send",o);if(!n.data.success)throw new Error(n.data.error||"Failed to send message");return n.data.data}catch(o){throw console.error("Error sending message:",o),o}}async checkAgentAvailability(){var e;try{const r=await this.api.get("/agent/status");return r.data.success&&((e=r.data.data)==null?void 0:e.available)||!1}catch(r){return console.error("Error checking agent availability:",r),!1}}async getAgentInfo(){try{const e=await this.api.get("/agent/info");return e.data.success&&e.data.data||null}catch(e){return console.error("Error getting agent info:",e),null}}updateConfig(e){this.config={...this.config,...e},this.api.defaults.headers["X-Marketrix-ID"]=this.config.marketrixId,this.api.defaults.headers["X-Marketrix-Key"]=this.config.marketrixKey}getConfig(){return{...this.config}}}class ze{constructor(e){j(this,"config");j(this,"currentContext",null);j(this,"currentStepGuide",null);j(this,"currentStepIndex",0);j(this,"contextMessages",{dashboard:{question:"I see you're looking at the Dashboard button! Would you like me to show you how to navigate to the main dashboard or explain what key metrics you'll find there?",responses:{show:"Let me highlight the key areas of the dashboard for you! The main dashboard shows your most important business metrics at a glance.",tell:"The dashboard is your command center! It displays real-time metrics like revenue, orders, customer count, and conversion rates. You can customize which widgets appear based on your business priorities.",do:"I can help you customize your dashboard layout. Would you like me to add specific widgets or rearrange the current ones to better suit your workflow?"}},products:{question:"Interested in product management? I can show you how to add new products, manage inventory, or explain the product catalog features!",responses:{show:"Here's how product management works - I'll walk you through adding a new product step by step!",tell:"The Products section lets you manage your entire inventory. You can add new items, set pricing, manage stock levels, organize into categories, and track performance metrics for each product.",do:"I can help you add a new product right now! Just tell me the product details and I'll guide you through the process."}},orders:{question:"Looking at order management? I can explain the order workflow, show you how to process orders, or help you track specific orders!",responses:{show:"Let me demonstrate the order processing workflow from receipt to delivery!",tell:"Order management handles your entire fulfillment process. Orders flow through stages: received → payment processing → fulfillment → delivery. You can track each order's status and manage any issues that arise.",do:"I can help you process pending orders or update order statuses. Which orders would you like me to help you with?"}},customers:{question:"Looking at customer management? I can show you customer profiles, explain segmentation, or help you with customer service tasks!",responses:{show:"Let me walk you through the customer management interface and show you how to view customer details and history!",tell:"Customer management gives you a complete view of your customers - their purchase history, preferences, support tickets, and lifetime value. You can segment customers for targeted marketing.",do:"I can help you find specific customers, update their information, or resolve customer service issues. What would you like me to help with?"}},analytics:{question:"Interested in analytics? I can show you key reports, explain the metrics, or help you create custom dashboards!",responses:{show:"Let me demonstrate the analytics dashboard and show you the most important reports for your business!",tell:"Analytics provides deep insights into your business performance - sales trends, customer behavior, product performance, and marketing effectiveness. You can create custom reports and set up automated alerts.",do:"I can generate specific reports for you or set up automated analytics alerts. What metrics would you like me to analyze?"}},settings:{question:"Need help with settings? I can show you system configuration, explain different options, or help you update your preferences!",responses:{show:"Let me guide you through the settings panel and show you the most important configuration options!",tell:"Settings allow you to customize your system preferences, payment gateways, shipping options, tax configurations, user permissions, and integrations with other tools.",do:"I can help you configure specific settings or update your system preferences. What settings would you like me to adjust?"}},revenue:{question:"I notice you're checking the revenue metrics! Would you like me to explain what drives this number or show you how to improve revenue growth?",responses:{show:"Let me break down your revenue sources and show you which products and channels are performing best!",tell:"Your monthly revenue of $24,563 represents a healthy 12.5% growth! This includes sales from all channels minus returns and refunds. The growth indicates strong business momentum.",do:"I can help you identify opportunities to increase revenue. Would you like me to analyze your top-performing products or suggest pricing optimizations?"}},"orders-count":{question:"Looking at order volume? I can explain order trends, show you order details, or help you optimize order processing!",responses:{show:"Let me show you the order breakdown by status and highlight any orders that need attention!",tell:"You've processed 342 orders this month with 8.3% growth! This includes new orders, completed orders, and any cancelled or refunded orders. The growth shows increasing customer demand.",do:"I can help you process pending orders, update order statuses, or identify orders that need special attention. What would you like me to focus on?"}},"customers-count":{question:"Checking customer numbers? I can show you customer segments, explain growth patterns, or help you with customer retention!",responses:{show:"Let me show you your customer breakdown by segments and highlight your most valuable customers!",tell:"You have 1,247 active customers with impressive 15.2% growth! This includes new registrations, repeat customers, and active users. The growth indicates strong customer acquisition.",do:"I can help you identify at-risk customers, create retention campaigns, or analyze customer lifetime value. What customer insights would you like me to provide?"}},conversion:{question:"I see you're looking at conversion rates. The 3.8% rate with a -2.1% change needs attention! Want me to explain what's happening or suggest improvements?",responses:{show:"Let me show you the conversion funnel and highlight where visitors are dropping off!",tell:"A 3.8% conversion rate means about 38 out of every 1,000 visitors make a purchase. The recent 2.1% decline could be due to seasonal factors, website issues, or increased competition. Industry average is typically 2-4%.",do:"I can help improve your conversion rate! Let me analyze your checkout process, product pages, and suggest A/B tests to optimize conversions."}},"add-product":{question:"Ready to add a new product? I can walk you through the entire process step-by-step or explain what information you'll need!",responses:{show:"Let me guide you through adding a new product - from basic details to pricing and inventory setup!",tell:"Adding a product requires: product name, description, category, pricing, inventory count, images, and SEO details. You can also set up variants for different sizes/colors and configure shipping options.",do:"I'll help you add a new product right now! What type of product are you adding? I'll collect all the necessary information and create the listing for you."}},"bulk-import":{question:"Need to import multiple products? I can show you the import process, explain file formats, or help you prepare your data!",responses:{show:"Let me demonstrate the bulk import process and show you how to format your product data correctly!",tell:"Bulk import allows you to add hundreds of products at once using CSV or Excel files. You'll need columns for name, description, price, inventory, categories, and images. The system validates data before import.",do:"I can help you prepare your import file or guide you through the import process. Do you have a product file ready to import?"}},categories:{question:"Working with product categories? I can show you category management, explain organization strategies, or help you restructure your catalog!",responses:{show:"Let me show you how to create and organize product categories for better customer navigation!",tell:"Categories help customers find products easily and improve your SEO. You can create hierarchical categories (main > sub > specific), assign products to multiple categories, and use categories for targeted marketing.",do:"I can help you reorganize your categories, create new ones, or assign products to better categories. What category structure would work best for your products?"}},inventory:{question:"Checking inventory levels? I can show you stock status, explain inventory alerts, or help you manage stock levels!",responses:{show:"Let me show you your current inventory status and highlight products that need restocking!",tell:"Inventory management tracks stock levels, sets low-stock alerts, manages supplier information, and handles reorder points. You can set up automatic reordering and track inventory across multiple locations.",do:"I can help you update stock levels, set up low inventory alerts, or create reorder reports. Which inventory tasks would you like me to handle?"}},"order-received":{question:"Looking at the order received step? I can explain what happens when orders come in or show you order processing workflow!",responses:{show:"Let me show you what happens when a new order is received and how it enters your processing queue!",tell:"When orders are received, the system captures customer details, validates payment information, checks inventory availability, and creates an order record. Orders then move to payment processing.",do:"I can help you review new orders, handle order issues, or update order details. Are there specific orders you'd like me to check?"}},"payment-processing":{question:"I see you're looking at the payment processing step! Need help understanding how payments work or troubleshooting payment issues?",responses:{show:"Let me show you how payment processing works and what happens when payments succeed or fail!",tell:"Payment processing verifies customer payment methods, charges the amount, and confirms the transaction. This step includes fraud detection, currency conversion if needed, and integration with your payment gateway.",do:"I can help you resolve payment issues or update payment settings. Are there specific payment problems you'd like me to investigate?"}},fulfillment:{question:"Looking at fulfillment? I can show you the picking and packing process, explain shipping options, or help you optimize fulfillment!",responses:{show:"Let me demonstrate the fulfillment workflow from inventory picking to package preparation!",tell:"Fulfillment involves picking items from inventory, packing them securely, generating shipping labels, and preparing packages for delivery. You can optimize this process with barcode scanning and automated packing slips.",do:"I can help you process fulfillment tasks, generate packing slips, or optimize your fulfillment workflow. What fulfillment tasks need attention?"}},delivery:{question:"Checking delivery status? I can show you shipping tracking, explain delivery options, or help you manage delivery issues!",responses:{show:"Let me show you how to track deliveries and manage shipping notifications for customers!",tell:"Delivery management includes shipping carrier integration, tracking number generation, customer notifications, and handling delivery exceptions. You can offer multiple shipping options and track delivery performance.",do:"I can help you track specific deliveries, resolve shipping issues, or update delivery preferences. Which deliveries need attention?"}},"customer-segments":{question:"Checking out customer segments? I can explain how these segments are created or show you how to target each group effectively!",responses:{show:"Let me show you what defines each customer segment and how to create targeted campaigns for each group!",tell:"Your customers are segmented by purchase behavior: VIP customers (23%) are high-value repeat buyers, Regular buyers (45%) purchase consistently, and New customers (32%) are first-time buyers. Each segment needs different marketing approaches.",do:"I can help you create targeted campaigns for each segment. Which customer group would you like to focus on first?"}},"support-tickets":{question:"Looking at support tickets? I can show you ticket management, explain response strategies, or help you resolve specific issues!",responses:{show:"Let me show you the support ticket interface and demonstrate how to efficiently handle customer inquiries!",tell:"You have 12 open tickets with an average response time of 2.3 hours. Support ticket management includes categorizing issues, prioritizing urgent matters, and tracking resolution time to maintain customer satisfaction.",do:"I can help you review open tickets, draft responses, or escalate urgent issues. Which support tickets need immediate attention?"}},"email-campaigns":{question:"Interested in email marketing? I can show you how to create campaigns, explain best practices, or help you launch your first campaign!",responses:{show:"Let me demonstrate how to create an effective email campaign from template selection to sending!",tell:"Email campaigns let you reach customers with personalized messages, promotional offers, and product updates. You can segment your audience, use templates, track open rates, and automate follow-ups based on customer behavior.",do:"I can help you create and launch an email campaign right now! What type of campaign would you like to send - promotional, newsletter, or product announcement?"}},"discount-codes":{question:"Working with discount codes? I can show you how to create promotions, explain different discount types, or help you set up special offers!",responses:{show:"Let me show you how to create different types of discount codes and set up promotional campaigns!",tell:"Discount codes can be percentage-based, fixed amount, or free shipping. You can set usage limits, expiration dates, minimum order amounts, and restrict to specific products or customer segments.",do:"I can help you create discount codes for specific promotions. What type of discount would you like to set up - seasonal sale, new customer offer, or loyalty reward?"}},"social-media":{question:"Managing social media? I can show you social integration features, explain posting strategies, or help you connect your accounts!",responses:{show:"Let me show you how to integrate social media accounts and manage your social presence from the dashboard!",tell:"Social media management includes connecting your Facebook, Instagram, and Twitter accounts, scheduling posts, sharing products, and tracking engagement. You can also import social media orders and manage social customer service.",do:"I can help you connect social media accounts, schedule posts, or create social media campaigns. Which social platforms would you like to set up?"}},login:{question:"Need help with login? I can show you how to sign in, explain the login process, or help you with account access!",responses:{show:"Let me guide you through the login process step-by-step! I'll show you how to enter your credentials and access your account.",tell:"The login process requires your email address and password. Once authenticated, you'll have access to all your account features and data. Make sure to use the correct credentials associated with your account.",do:"I'll help you log in right now! Let me walk you through each step of the login process with visual guidance."}}});j(this,"stepGuides",{"add-product":[{step_number:1,action:"click",element:"button",text:"Products",description:"Click on the 'Products' button in the navigation to access the product management section",selector:"[data-demo-element='products']"},{step_number:2,action:"click",element:"button",text:"Add New Product",description:"Click on the 'Add New Product' button to start creating a new product",selector:"[data-demo-element='add-product']"},{step_number:3,action:"fill",element:"form",description:"Fill in the product details: name, description, price, and upload product images. Then click 'Save Product' to add it to your catalog",selector:"[data-demo-element='product-form']"}],"bulk-import":[{step_number:1,action:"click",element:"button",text:"Products",description:"Navigate to the Products section from the navigation"},{step_number:2,action:"click",element:"button",text:"Bulk Import",description:"Click on the 'Bulk Import' button to upload multiple products at once"},{step_number:3,action:"upload",element:"file",description:"Upload your CSV or Excel file with product data. Make sure it includes columns for name, description, price, and category"}],"setup-widget":[{step_number:1,action:"click",element:"button",text:"Settings",description:"Click on the 'Settings' button in the navigation"},{step_number:2,action:"click",element:"button",text:"Set Up & Check Connection",description:"Click on the 'Set Up & Check Connection' button to proceed with setup"},{step_number:3,action:"click",element:"button",text:"Copy Code",description:"Click the 'Copy Code' button to copy the setup code to your clipboard"},{step_number:4,action:"paste",element:"html",description:"Add the copied code to your website's HTML code before the closing </body> tag"}],login:[{step_number:1,action:"click",element:"button",text:"Login",description:"Click on the 'Login' button to access the login form. This will open the authentication dialog where you can enter your credentials.",selector:"[data-demo-element='login-button']"},{step_number:2,action:"fill",element:"input",text:"Username/Email",description:"Enter your username or email address in the field. Example: john.doe@example.com or john_doe. Make sure it's a valid format and matches your account.",selector:"[data-demo-element='login-email']"},{step_number:3,action:"fill",element:"input",text:"Password",description:"Enter your password in the password field. Ensure it matches your account password. The password is case-sensitive and should be at least 8 characters long.",selector:"[data-demo-element='login-password']"},{step_number:4,action:"click",element:"button",text:"Sign In",description:"Click the 'Sign In' button to complete the login process and access your account. Make sure you've entered the correct credentials before clicking.",selector:"[data-demo-element='login-submit']"}]});j(this,"handleStepElementClick",e=>{if(e.preventDefault(),e.stopPropagation(),!this.currentStepGuide)return;const r=e.target,o=parseInt(r.getAttribute("data-step-index")||"0");if(o!==this.currentStepIndex){console.log("Click on step",o,"but current step is",this.currentStepIndex);return}const n=this.currentStepGuide[this.currentStepIndex];console.log("Step element clicked:",n),r.classList.add("step-element-clicked"),setTimeout(()=>{r.classList.remove("step-element-clicked")},300),n.action==="fill"?this.handleFormInputStep(r,n):(this.removeStepHighlights(),this.markStepAsCompleted(this.currentStepIndex),setTimeout(()=>{this.nextStep()},300)),console.log("Step completed. Proceeding to next step.")});j(this,"handleInputValidation",e=>{const r=e.target;if(!r.currentStep)return;const n=r.value.trim().length>0;this.updateTickButtonState(n)});j(this,"handleInputBlur",e=>{const r=e.target;if(!r.currentStep)return;r.value.trim().length>0?this.showInputSuccess(r):this.showInputError(r)});this.config=e}async sendMessage(e,r){if(await new Promise(i=>setTimeout(i,1e3+Math.random()*1e3)),this.isStepGuideRequest(e))return this.handleStepGuideRequest(e,r);let o=this.currentContext||window.currentDemoContext;if(o||(o=this.analyzeMessageForContext(e)),o&&this.contextMessages[o]){const a=this.contextMessages[o].responses[r];return r==="show"&&this.navigateToElement(o),{messageId:this.generateId(),response:a,timestamp:new Date,mode:r}}const n=this.analyzeMessageForContext(e);if(n&&this.contextMessages[n]){const a=this.contextMessages[n].responses[r];return r==="show"&&this.navigateToElement(n),{messageId:this.generateId(),response:a,timestamp:new Date,mode:r}}const s={show:"I'd be happy to show you how this works! In a real implementation, I would provide step-by-step visual guidance. Try hovering over different elements on the page to see contextual help!",tell:"Let me explain how this feature works. In this demo, I can provide detailed explanations about any element you hover over. The system is designed to give contextual help based on what you're looking at.",do:"I'm ready to help you accomplish this task! In a production environment, I would be able to perform actions on your behalf. For now, try hovering over different buttons and sections to see how I can assist with specific features."};return{messageId:this.generateId(),response:s[r]||"I'm here to help! Try hovering over different elements on the page to see contextual assistance.",timestamp:new Date,mode:r}}async checkAgentAvailability(){return!0}async getAgentInfo(){return{name:"Marketrix Demo Assistant",avatarUrl:"https://via.placeholder.com/64/0ea5e9/ffffff?text=AI"}}setCurrentContext(e){this.currentContext=e}getContextMessage(e){return this.contextMessages[e]||null}updateConfig(e){this.config={...this.config,...e}}getConfig(){return{...this.config}}analyzeMessageForContext(e){const r=e.toLowerCase(),o={dashboard:["dashboard","overview","main page","home","main"],products:["product","inventory","catalog","items","merchandise"],orders:["order","purchase","transaction","sale","buy","sold"],customers:["customer","user","client","buyer","people"],analytics:["analytics","report","data","insight","metric","stats"],settings:["setting","config","preference","option","setup"],revenue:["revenue","money","income","earning","profit","sales","$"],conversion:["conversion","convert","rate","percentage","%"],"add-product":["add product","create product","new product","add item","create item"],"bulk-import":["bulk import","import","upload","batch","csv","excel"],categories:["category","organize","group","classification"],inventory:["inventory","stock","quantity","warehouse"],"payment-processing":["payment","pay","transaction","billing","checkout"],fulfillment:["fulfillment","fulfill","ship","delivery","shipping"],"customer-segments":["segment","group","vip","customer type","classification"],"email-campaigns":["email","campaign","marketing","newsletter","promotion"],"discount-codes":["discount","coupon","promo","offer","sale"],"social-media":["social","facebook","instagram","twitter","media"],login:["login","sign in","log in","authenticate","access","credentials"]};for(const[n,s]of Object.entries(o))if(s.some(i=>r.includes(i)))return n;return null}navigateToElement(e){try{const r=document.querySelector(`[data-demo-element="${e}"]`);r&&(r.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),this.highlightElement(r),window.currentDemoContext=e)}catch(r){console.error("Error navigating to element:",r)}}highlightElement(e){this.addHighlightStyles(),this.removeExistingHighlights(),e.classList.add("demo-highlight"),e.style.transition="all 0.3s ease",this.createDescriptionOverlay(e),setTimeout(()=>{this.removeHighlight(e)},5e3)}removeExistingHighlights(){document.querySelectorAll(".demo-highlight").forEach(o=>{o.classList.remove("demo-highlight")});const e=document.getElementById("highlight-overlay");e&&e.remove();const r=document.getElementById("highlight-description");r&&r.remove()}removeHighlight(e){e.classList.remove("demo-highlight"),e.style.transition="";const r=document.getElementById("highlight-overlay");r&&(r.style.animation="fadeOut 0.3s ease-out forwards",setTimeout(()=>r.remove(),300));const o=document.getElementById("highlight-description");o&&(o.style.animation="fadeOut 0.3s ease-out forwards",setTimeout(()=>o.remove(),300))}createDescriptionOverlay(e){const r=e.getBoundingClientRect(),o=e.getAttribute("data-demo-element"),n=this.getElementDescription(o),s=document.createElement("div");s.id="highlight-overlay",s.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(4px);
      z-index: 999;
      pointer-events: none;
      animation: overlayFadeIn 0.4s ease-out;
    `,document.body.appendChild(s);const i=document.createElement("div");i.id="highlight-description",i.innerHTML=`
      <div class="description-content">
        <div class="description-title">${this.getElementTitle(o)}</div>
        <div class="description-text">${n}</div>
      </div>
    `;const a=320,p=120;let c=r.left+r.width/2-a/2,u=r.top-p-20;c<20&&(c=20),c+a>window.innerWidth-20&&(c=window.innerWidth-a-20),u<20&&(u=r.bottom+20),i.style.cssText=`
      position: fixed;
      left: ${c}px;
      top: ${u}px;
      width: ${a}px;
      z-index: 1000;
      pointer-events: none;
      animation: descriptionSlideIn 0.4s ease-out;
    `,document.body.appendChild(i)}getElementTitle(e){return e&&{dashboard:"Dashboard",products:"Products",orders:"Orders",customers:"Customers",analytics:"Analytics",settings:"Settings",revenue:"Revenue","orders-count":"Order Count","customers-count":"Customer Count",conversion:"Conversion Rate","add-product":"Add Product","bulk-import":"Bulk Import",categories:"Categories",inventory:"Inventory","order-received":"Order Received","payment-processing":"Payment Processing",fulfillment:"Fulfillment",delivery:"Delivery","customer-segments":"Customer Segments","support-tickets":"Support Tickets","email-campaigns":"Email Campaigns","discount-codes":"Discount Codes","social-media":"Social Media"}[e]||"Interactive Element"}getElementDescription(e){return e&&{dashboard:"Your main control center showing key business metrics and navigation options.",products:"Manage your product catalog, inventory, and product-related settings.",orders:"View and process customer orders, track order status and fulfillment.",customers:"Access customer information, segments, and customer service tools.",analytics:"View detailed reports, metrics, and business intelligence insights.",settings:"Configure system preferences, integrations, and account settings.",revenue:"Track your revenue performance and financial metrics.","orders-count":"Monitor the number of orders processed and order volume trends.","customers-count":"View customer growth and active customer statistics.",conversion:"Track conversion rates and optimize your sales funnel performance.","add-product":"Add new products to your catalog with detailed information.","bulk-import":"Import multiple products at once using CSV or Excel files.",categories:"Organize products into categories for better navigation and SEO.",inventory:"Manage stock levels, set alerts, and track inventory across locations.","order-received":"New orders that have been received and are ready for processing.","payment-processing":"Orders currently being processed for payment verification.",fulfillment:"Orders being prepared for shipping and delivery.",delivery:"Orders that have been shipped and are in transit to customers.","customer-segments":"Group customers by behavior, value, or other characteristics.","support-tickets":"Manage customer support requests and service tickets.","email-campaigns":"Create and manage email marketing campaigns and newsletters.","discount-codes":"Set up promotional codes, coupons, and special offers.","social-media":"Connect and manage your social media accounts and posts."}[e]||"Click to explore this feature"}addHighlightStyles(){if(!document.getElementById("highlight-styles")){const e=document.createElement("style");e.id="highlight-styles",e.textContent=`
        .demo-highlight {
          outline: 2px solid #3B82F6 !important;
          outline-offset: 2px !important;
          box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.2) !important;
          border-radius: 4px !important;
          position: relative !important;
          z-index: 1001 !important;
        }
        
        .description-content {
          background: rgba(255, 255, 255, 0.95);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(59, 130, 246, 0.3);
          border-radius: 12px;
          padding: 16px;
          box-shadow: 
            0 8px 32px rgba(0, 0, 0, 0.1),
            0 0 0 1px rgba(59, 130, 246, 0.1);
        }
        
        .description-title {
          font-size: 16px;
          font-weight: 700;
          color: #1E40AF;
          margin-bottom: 8px;
          line-height: 1.3;
        }
        
        .description-text {
          font-size: 14px;
          color: #374151;
          line-height: 1.5;
          opacity: 0.9;
        }
        
        @keyframes overlayFadeIn {
          from { 
            opacity: 0; 
            backdrop-filter: blur(0px); 
          }
          to { 
            opacity: 1; 
            backdrop-filter: blur(4px); 
          }
        }
        
        @keyframes descriptionSlideIn {
          from { 
            opacity: 0; 
            transform: translateY(-20px) scale(0.95); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0) scale(1); 
          }
        }
        
        @keyframes fadeOut {
          to { 
            opacity: 0; 
            transform: scale(0.95);
          }
        }
      `,document.head.appendChild(e)}}isStepGuideRequest(e){const r=e.toLowerCase();return["show me how to","how do i","step by step","guide me through","walk me through","tutorial","add a new product","bulk import","setup widget","set up widget","login","sign in","log in"].some(n=>r.includes(n))}async handleStepGuideRequest(e,r){const o=e.toLowerCase();let n="add-product";o.includes("add")&&o.includes("product")?n="add-product":o.includes("bulk")&&o.includes("import")?n="bulk-import":o.includes("setup")||o.includes("set up")||o.includes("widget")?n="setup-widget":(o.includes("login")||o.includes("sign in")||o.includes("log in"))&&(n="login");const s=this.stepGuides[n];if(!s||s.length===0)return console.error("No steps found for guide type:",n),{messageId:this.generateId(),response:"I don't have a step-by-step guide for that yet. Try asking about adding products, bulk importing, or setting up the widget.",timestamp:new Date,mode:r};if(console.log("Starting step guide for:",n,"with steps:",s),r==="show")return this.startStepGuide(s),{messageId:this.generateId(),response:`Perfect! I'll show you step-by-step how to ${this.getGuideTitle(n)}. Let me start the interactive guide for you.`,timestamp:new Date,mode:r};if(r==="tell"){const i=s.map(a=>`**Step ${a.step_number}:** ${a.description}`).join(`

`);return{messageId:this.generateId(),response:`Here's how to ${this.getGuideTitle(n)}:

${i}`,timestamp:new Date,mode:r}}else return this.startStepGuide(s),{messageId:this.generateId(),response:`I'll help you ${this.getGuideTitle(n)} right now! Let me start the interactive guide.`,timestamp:new Date,mode:r}}getGuideTitle(e){return{"add-product":"add a new product","bulk-import":"bulk import products","setup-widget":"set up the widget",login:"log in to your account"}[e]||"complete this task"}startStepGuide(e){if(!e||e.length===0){console.error("Cannot start step guide: no steps provided");return}this.currentStepGuide=e,this.currentStepIndex=0,console.log("Starting step guide with",e.length,"steps"),console.log("Steps:",e),this.addStepGuideStyles(),this.addBackgroundBlur(),this.addStepClickHandlers(),this.showCurrentStep(),this.highlightCurrentStepElement()}showCurrentStep(){if(!this.currentStepGuide||this.currentStepGuide.length===0||this.currentStepIndex>=this.currentStepGuide.length){console.error("Invalid step guide state:",{currentStepGuide:this.currentStepGuide,currentStepIndex:this.currentStepIndex});return}if(!this.currentStepGuide[this.currentStepIndex]){console.error("Current step is undefined:",{currentStepIndex:this.currentStepIndex,totalSteps:this.currentStepGuide.length});return}this.removeStepGuideUI(),window.stepGuideNext=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.removeStepHighlights(),this.markStepAsCompleted(this.currentStepIndex),setTimeout(()=>{this.nextStep()},200)},window.stepGuidePrev=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.prevStep()}}addStepClickHandlers(){this.currentStepGuide&&(console.log("Adding click handlers for",this.currentStepGuide.length,"steps"),this.currentStepGuide.forEach((e,r)=>{const o=e.selector||`[data-demo-element="${e.element}"]`,n=document.querySelector(o);console.log(`Step ${r+1}: Looking for element with selector:`,o),n?(console.log(`Step ${r+1}: Element found:`,n),n.setAttribute("data-step-index",r.toString()),n.removeEventListener("click",this.handleStepElementClick),n.addEventListener("click",this.handleStepElementClick),console.log(`Step ${r+1}: Click handler added`)):console.warn(`Step ${r+1}: Element not found for selector:`,o)}))}handleFormInputStep(e,r){(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)&&(e.focus(),this.addInputValidation(e,r))}addInputValidation(e,r){(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)&&(e.removeEventListener("input",this.handleInputValidation),e.removeEventListener("blur",this.handleInputBlur),e.addEventListener("input",this.handleInputValidation),e.addEventListener("blur",this.handleInputBlur),e.currentStep=r)}updateTickButtonState(e){const r=document.querySelector(".step-tick-button");r&&(r.disabled=!e,r.style.opacity=e?"1":"0.5",r.style.cursor=e?"pointer":"not-allowed")}showInputSuccess(e){e.style.borderColor="#10b981",e.style.boxShadow="0 0 0 3px rgba(16, 185, 129, 0.1)"}showInputError(e){e.style.borderColor="#ef4444",e.style.boxShadow="0 0 0 3px rgba(239, 68, 68, 0.1)"}markStepAsCompleted(e){console.log("Marking step as completed:",e);const r=document.querySelector(`[data-step-completed="${e}"]`);r&&r.classList.add("step-completed")}nextStep(){if(!this.currentStepGuide||this.currentStepGuide.length===0){console.error("Cannot navigate to next step: no step guide available");return}this.removeStepHighlights(),this.markStepAsCompleted(this.currentStepIndex),this.currentStepIndex<this.currentStepGuide.length-1?(this.currentStepIndex++,setTimeout(()=>{var e,r;this.showCurrentStep(),this.highlightCurrentStepElement(),this.currentStepIndex===2&&((e=this.currentStepGuide[this.currentStepIndex])==null?void 0:e.action)==="fill"&&this.showProductForm(),this.currentStepIndex===1&&((r=this.currentStepGuide[this.currentStepIndex])==null?void 0:r.action)==="fill"&&this.showLoginForm()},200)):(console.log("Final step completed - removing all highlights"),this.removeStepHighlights(),setTimeout(()=>{this.showGuideCompletion()},300))}showProductForm(){const e=document.getElementById("product-form-simulation");e&&(e.style.display="block",e.scrollIntoView({behavior:"smooth",block:"center"}))}showLoginForm(){const e=document.getElementById("login-form-simulation");e&&(e.style.display="block",e.scrollIntoView({behavior:"smooth",block:"center"}))}prevStep(){if(!this.currentStepGuide||this.currentStepGuide.length===0){console.error("Cannot navigate to previous step: no step guide available");return}if(this.currentStepIndex===0){console.log("Already at first step");return}this.removeStepHighlights(),this.currentStepIndex--,this.showCurrentStep(),this.highlightCurrentStepElement(),this.addStepClickHandlers(),console.log("Navigated to previous step:",this.currentStepIndex+1)}highlightCurrentStepElement(){if(!this.currentStepGuide||this.currentStepGuide.length===0||this.currentStepIndex>=this.currentStepGuide.length){console.error("Cannot highlight step element: invalid step guide state");return}const e=this.currentStepGuide[this.currentStepIndex];if(!e){console.error("Current step is undefined");return}const r=e.selector||`[data-demo-element="${e.element}"]`;console.log("Looking for element with selector:",r);const o=document.querySelector(r);if(o)console.log("Element found:",o),o.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),this.highlightStepElement(o);else{console.warn("Element not found for selector:",r);const n=[`#${e.element}`,`.${e.element}`,`[id="${e.element}"]`,`[class*="${e.element}"]`];for(const s of n){const i=document.querySelector(s);if(i){console.log("Found element with alternative selector:",s,i),i.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),this.highlightStepElement(i);return}}}}highlightStepElement(e){this.removeStepHighlights(),e.classList.add("step-guide-highlight"),this.createStepSpotlight(e),this.createStepDescriptionText(e)}createStepSpotlight(e){const r=e.getBoundingClientRect(),o=document.createElement("div");o.id="step-spotlight",o.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: radial-gradient(ellipse at ${r.left+r.width/2}px ${r.top+r.height/2}px, 
        transparent 0%, 
        transparent 40%, 
        rgba(0, 0, 0, 0.4) 100%);
      z-index: 9999;
      pointer-events: none;
      animation: spotlightFadeIn 0.3s ease-out;
    `,document.body.appendChild(o);const n=document.createElement("div");n.style.cssText=`
      position: absolute;
      left: ${r.left-4}px;
      top: ${r.top-4}px;
      width: ${r.width+8}px;
      height: ${r.height+8}px;
      border: 3px solid #3b82f6;
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
      z-index: 10000;
      pointer-events: none;
      animation: stepPulse 2s infinite;
    `,document.body.appendChild(n),e.stepSpotlight=o,e.stepBorder=n}createStepDescriptionText(e){if(!this.currentStepGuide||this.currentStepIndex>=this.currentStepGuide.length)return;const r=this.currentStepGuide[this.currentStepIndex];console.log("Creating description text for step:",r);const o=e.getBoundingClientRect(),n=document.createElement("div");n.id=`step-description-text-${this.currentStepIndex}`,n.innerHTML=`
      <div class="step-description-text-content">
        <div class="step-description-text-body">
          <div class="step-description-text-description" id="typing-text-${this.currentStepIndex}"></div>
          <span class="step-description-text-cursor">|</span>
        </div>
        ${r.action==="fill"?`
          <div class="step-description-text-actions" style="display: none; opacity: 0;">
            <button class="step-tick-button" type="button" onclick="event.preventDefault(); event.stopPropagation(); window.stepGuideNext && window.stepGuideNext()">
              <span class="tick-text">Done</span>
            </button>
          </div>
        `:""}
      </div>
    `;const s=320,i=r.action==="fill"?140:120,a=20;let p,c;const u=[{left:o.left+(o.width-s)/2,top:o.bottom+a,name:"below"},{left:o.right+a,top:o.top+(o.height-i)/2,name:"right"},{left:o.left-s-a,top:o.top+(o.height-i)/2,name:"left"},{left:o.left+(o.width-s)/2,top:o.top-i-a,name:"above"}];for(const f of u)if(f.left>=a&&f.left+s<=window.innerWidth-a&&f.top>=a&&f.top+i<=window.innerHeight-a){p=f.left,c=f.top;break}(p===void 0||c===void 0)&&(p=(window.innerWidth-s)/2,c=(window.innerHeight-i)/2),console.log("Description text positioning:",{elementRect:o,finalPosition:{left:p,top:c},textSize:{width:s,height:i},screenSize:{width:window.innerWidth,height:window.innerHeight}}),n.style.cssText=`
      position: fixed;
      left: ${p}px;
      top: ${c}px;
      width: ${s}px;
      height: ${i}px;
      z-index: 10001;
      pointer-events: auto;
      animation: stepDescriptionTextSlideIn 0.3s ease-out;
    `,document.body.appendChild(n),this.startTypingAnimation(r.description,this.currentStepIndex),e.stepDescriptionText=n}startTypingAnimation(e,r){const o=document.getElementById(`typing-text-${r}`);if(!o){console.error("Typing element not found for step:",r);return}console.log("Starting typing animation with text:",e);let n=0;const s=20,i=()=>{n<e.length?(o.textContent=e.substring(0,n+1),n++,setTimeout(i,s)):(this.showDoneButton(r),setTimeout(()=>{const a=document.querySelector(`#typing-text-${r}`);if(a){const p=a.nextElementSibling;p&&(p.style.opacity="0")}},1e3))};setTimeout(i,500)}showDoneButton(e){const r=document.getElementById(`step-description-text-${e}`);if(!r)return;const o=r.querySelector(".step-description-text-actions");o&&(o.style.display="flex",o.style.opacity="0",o.style.transform="translateY(10px)",setTimeout(()=>{o.style.transition="all 0.3s ease-out",o.style.opacity="1",o.style.transform="translateY(0)"},100))}removeStepHighlights(){console.log("Removing step highlights"),document.querySelectorAll(".step-guide-highlight").forEach(o=>{o.classList.remove("step-guide-highlight")});const e=document.getElementById("step-spotlight");e&&(console.log("Removing spotlight"),e.remove());const r=document.getElementById("step-description-button");r&&r.remove(),document.querySelectorAll('[id^="step-description-text-"]').forEach(o=>o.remove()),document.querySelectorAll("[data-step-border]").forEach(o=>o.remove()),document.querySelectorAll(".step-spotlight").forEach(o=>o.remove()),document.querySelectorAll('[style*="animation: stepPulse"]').forEach(o=>{o.style.animation="none"}),document.querySelectorAll(".step-indicator, .step-completed, .step-element-clicked").forEach(o=>{o.classList.remove("step-indicator","step-completed","step-element-clicked")})}removeStepGuideUI(){this.removeStepHighlights(),this.removeBackgroundBlur()}showIPhoneNotification(e,r,o="success"){console.log("Showing iPhone notification:",{title:e,message:r,type:o});const n=document.getElementById("iphone-notification");n&&n.remove();const s=document.createElement("div");s.id="iphone-notification";const i={success:"✅",info:"ℹ️",warning:"⚠️",error:"❌"};s.innerHTML=`
      <div class="iphone-notification-content">
        <div class="iphone-notification-icon">${i[o]}</div>
        <div class="iphone-notification-text">
          <div class="iphone-notification-title">${e}</div>
          <div class="iphone-notification-message">${r}</div>
        </div>
        <div class="iphone-notification-close" onclick="this.parentElement.parentElement.style.animation='iphoneNotificationSlideUp 0.5s ease-out forwards'; setTimeout(() => this.parentElement.parentElement.remove(), 500)">×</div>
      </div>
    `,s.style.cssText=`
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(0, 0, 0, 0.95);
      backdrop-filter: blur(25px);
      border-radius: 20px;
      padding: 0;
      box-shadow: 
        0 25px 50px rgba(0, 0, 0, 0.4),
        0 0 0 1px rgba(255, 255, 255, 0.15),
        inset 0 1px 0 rgba(255, 255, 255, 0.1);
      z-index: 10000;
      animation: iphoneNotificationSlideDown 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
      max-width: 400px;
      min-width: 300px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.2);
    `,this.addIPhoneNotificationStyles(),document.body.appendChild(s),setTimeout(()=>{s.parentNode&&(s.style.animation="iphoneNotificationSlideUp 0.5s ease-out forwards",setTimeout(()=>{s.parentNode&&s.remove()},500))},4e3)}addIPhoneNotificationStyles(){if(!document.getElementById("iphone-notification-styles")){const e=document.createElement("style");e.id="iphone-notification-styles",e.textContent=`
        .iphone-notification-content {
          display: flex;
          align-items: center;
          padding: 16px 20px;
          gap: 12px;
          color: white;
          position: relative;
        }

        .iphone-notification-icon {
          font-size: 24px;
          flex-shrink: 0;
          filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3));
        }

        .iphone-notification-text {
          flex: 1;
          min-width: 0;
        }

        .iphone-notification-title {
          font-size: 16px;
          font-weight: 600;
          margin-bottom: 4px;
          line-height: 1.2;
          color: white;
          text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        }

        .iphone-notification-message {
          font-size: 14px;
          opacity: 0.9;
          line-height: 1.3;
          color: rgba(255, 255, 255, 0.9);
        }

        .iphone-notification-close {
          position: absolute;
          top: 8px;
          right: 8px;
          width: 24px;
          height: 24px;
          border-radius: 12px;
          background: rgba(255, 255, 255, 0.2);
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          font-size: 16px;
          font-weight: bold;
          transition: all 0.2s ease;
          backdrop-filter: blur(10px);
        }

        .iphone-notification-close:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.1);
        }

        @keyframes iphoneNotificationSlideDown {
          0% {
            opacity: 0;
            transform: translateX(-50%) translateY(-100px) scale(0.8);
          }
          20% {
            opacity: 0.8;
            transform: translateX(-50%) translateY(-20px) scale(0.95);
          }
          40% {
            opacity: 1;
            transform: translateX(-50%) translateY(10px) scale(1.02);
          }
          60% {
            opacity: 1;
            transform: translateX(-50%) translateY(-5px) scale(0.98);
          }
          80% {
            opacity: 1;
            transform: translateX(-50%) translateY(2px) scale(1.01);
          }
          100% {
            opacity: 1;
            transform: translateX(-50%) translateY(0) scale(1);
          }
        }

        @keyframes iphoneNotificationSlideUp {
          0% {
            opacity: 1;
            transform: translateX(-50%) translateY(0) scale(1);
          }
          20% {
            opacity: 0.8;
            transform: translateX(-50%) translateY(-10px) scale(0.98);
          }
          100% {
            opacity: 0;
            transform: translateX(-50%) translateY(-100px) scale(0.8);
          }
        }

        /* Success notification specific styling */
        .iphone-notification.success .iphone-notification-icon {
          color: #34C759;
        }

        .iphone-notification.info .iphone-notification-icon {
          color: #007AFF;
        }

        .iphone-notification.warning .iphone-notification-icon {
          color: #FF9500;
        }

        .iphone-notification.error .iphone-notification-icon {
          color: #FF3B30;
        }
      `,document.head.appendChild(e)}}showGuideCompletion(){console.log("Showing guide completion notification"),this.removeStepHighlights(),this.removeStepGuideUI(),setTimeout(()=>{typeof window<"u"&&document.querySelectorAll("form").forEach(r=>{r.addEventListener("submit",o=>{o.preventDefault(),o.stopPropagation()})}),this.showIPhoneNotification("Tour Completed! 🎉","Congratulations! You've successfully completed the entire step-by-step guide. Great job!","success")},500)}addBackgroundBlur(){const e=document.createElement("div");e.id="step-guide-blur-overlay",e.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(2px);
      z-index: 9998;
      pointer-events: none;
      animation: blurFadeIn 0.3s ease-out;
    `,document.body.appendChild(e)}removeBackgroundBlur(){const e=document.getElementById("step-guide-blur-overlay");e&&(e.style.animation="blurFadeOut 0.3s ease-out forwards",setTimeout(()=>{e.parentNode&&e.remove()},300))}addStepGuideStyles(){if(!document.getElementById("step-guide-styles")){const e=document.createElement("style");e.id="step-guide-styles",e.textContent=`
        /* Step Guide Panel */
        .step-guide-content {
          background: white;
          border-radius: 12px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
          overflow: hidden;
          border: 1px solid #e5e7eb;
        }
        
        .step-guide-header {
          background: linear-gradient(135deg, #3b82f6, #1d4ed8);
          color: white;
          padding: 16px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .step-guide-progress {
          flex: 1;
        }
        
        .step-guide-progress-bar {
          width: 100%;
          height: 4px;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 2px;
          overflow: hidden;
          margin-bottom: 8px;
        }
        
        .step-guide-progress-fill {
          height: 100%;
          background: white;
          border-radius: 2px;
          transition: width 0.3s ease;
        }
        
        .step-guide-step-counter {
          font-size: 12px;
          font-weight: 500;
          opacity: 0.9;
        }
        
        .step-guide-close {
          background: none;
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          padding: 4px;
          border-radius: 4px;
          transition: background-color 0.2s;
        }
        
        .step-guide-close:hover {
          background: rgba(255, 255, 255, 0.2);
        }
        
        .step-guide-body {
          padding: 20px;
          display: flex;
          align-items: flex-start;
          gap: 16px;
        }
        
        .step-guide-icon {
          font-size: 24px;
          flex-shrink: 0;
          margin-top: 4px;
        }
        
        .step-guide-text {
          flex: 1;
        }
        
        .step-guide-title {
          font-size: 16px;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 8px;
        }
        
        .step-guide-description {
          font-size: 14px;
          color: #6b7280;
          line-height: 1.5;
        }
        
        .step-guide-actions {
          padding: 16px 20px;
          background: #f9fafb;
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }
        
        .step-guide-prev,
        .step-guide-next {
          padding: 8px 16px;
          border-radius: 6px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          border: 1px solid #d1d5db;
          background: white;
          color: #374151;
        }
        
        .step-guide-prev:hover:not(:disabled) {
          background: #f3f4f6;
          border-color: #9ca3af;
        }
        
        .step-guide-prev:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        
        .step-guide-next {
          background: #3b82f6;
          color: white;
          border-color: #3b82f6;
        }
        
        .step-guide-next:hover {
          background: #2563eb;
          border-color: #2563eb;
        }
        
        .step-guide-instructions {
          padding: 12px 20px;
          background: #f0f9ff;
          border-top: 1px solid #e0f2fe;
        }
        
        .step-guide-hint {
          font-size: 12px;
          color: #0369a1;
          text-align: center;
          font-style: italic;
        }
        
        .step-guide-icon {
          margin: 0 4px;
          font-size: 12px;
        }
        
        /* Step highlighting */
        .step-guide-highlight {
          position: relative;
          z-index: 10001;
        }
        
        /* Completed step styling */
        .step-completed {
          opacity: 0.7;
          position: relative;
        }
        
        .step-completed::after {
          content: '✓';
          position: absolute;
          top: -8px;
          right: -8px;
          background: #10b981;
          color: white;
          border-radius: 50%;
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: bold;
          z-index: 10002;
        }
        
        /* Click feedback animation */
        .step-element-clicked {
          animation: stepClickFeedback 0.3s ease-out;
        }
        
        @keyframes stepClickFeedback {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        
        /* Step completion feedback */
        .step-completion-content {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .step-completion-icon {
          font-size: 24px;
          flex-shrink: 0;
        }
        
        .step-completion-text {
          flex: 1;
        }
        
        .step-completion-title {
          font-weight: 600;
          color: #10b981;
          font-size: 16px;
          margin-bottom: 4px;
        }
        
        .step-completion-description {
          font-size: 14px;
          color: #374151;
          line-height: 1.4;
        }
        
        @keyframes stepCompletionSlideIn {
          from {
            opacity: 0;
            transform: translate(-50%, -50%) scale(0.8);
          }
          to {
            opacity: 1;
            transform: translate(-50%, -50%) scale(1);
          }
        }
        
        /* Animations */
        @keyframes stepGuideSlideIn {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(-20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0) scale(1);
          }
        }
        
        @keyframes spotlightFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes stepPulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.02);
          }
        }
        
        /* Guide completion panel */
        .guide-completion-panel {
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
          width: 300px;
          border: 2px solid #10B981;
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px;
        }
        
        .guide-completion-icon {
          font-size: 24px;
          flex-shrink: 0;
        }
        
        .guide-completion-text {
          flex: 1;
        }
        
        .guide-completion-title {
          font-size: 16px;
          font-weight: 700;
          color: #1F2937;
          margin-bottom: 4px;
        }
        
        .guide-completion-description {
          font-size: 12px;
          color: #6B7280;
          line-height: 1.4;
        }
        
        /* Step indicator on highlighted elements */
        .step-indicator {
          position: absolute;
          top: -12px;
          right: -12px;
          background: #3B82F6;
          color: white;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 14px;
          z-index: 10001;
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
          animation: stepPulse 2s infinite;
          border: 3px solid white;
        }
        
        .step-description-overlay {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, 0.95);
          color: white;
          padding: 16px;
          border-radius: 12px;
          font-size: 14px;
          z-index: 10001;
          margin-top: 12px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
          animation: stepDescriptionSlide 0.3s ease-out;
          border: 2px solid #3B82F6;
          max-width: 300px;
          min-width: 200px;
        }
        
        @keyframes stepPulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }
        
        @keyframes stepDescriptionSlide {
          from { 
            opacity: 0; 
            transform: translateY(-10px); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0); 
          }
        }
        
        @keyframes guideFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        
        @keyframes guideSlideIn {
          from { 
            opacity: 0; 
            transform: translateY(-20px) scale(0.95); 
          }
          to { 
            opacity: 1; 
            transform: translateY(0) scale(1); 
          }
        }
         
         /* Step description button */
         .step-description-button-content {
           background: linear-gradient(135deg, #3b82f6, #1d4ed8);
           border-radius: 12px;
           padding: 12px 16px;
           box-shadow: 0 8px 24px rgba(59, 130, 246, 0.3);
           border: 2px solid rgba(255, 255, 255, 0.2);
           display: flex;
           align-items: center;
           gap: 12px;
           color: white;
           position: relative;
           overflow: hidden;
         }
         
         .step-description-button-content::before {
           content: '';
           position: absolute;
           top: 0;
           left: -100%;
           width: 100%;
           height: 100%;
           background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
           animation: shimmer 2s infinite;
         }
         
         .step-description-button-icon {
           font-size: 20px;
           flex-shrink: 0;
           filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
         }
         
         .step-description-button-text {
           flex: 1;
           min-width: 0;
         }
         
         .step-description-button-title {
           font-size: 14px;
           font-weight: 700;
           margin-bottom: 2px;
           text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
         }
         
         .step-description-button-subtitle {
           font-size: 12px;
           opacity: 0.9;
           white-space: nowrap;
           overflow: hidden;
           text-overflow: ellipsis;
         }
         
         .step-description-button-arrow {
           font-size: 16px;
           font-weight: bold;
           opacity: 0.8;
           animation: arrowPulse 1.5s infinite;
         }
         
         @keyframes stepDescriptionButtonSlideIn {
           from {
             opacity: 0;
             transform: translateX(-20px) scale(0.9);
           }
           to {
             opacity: 1;
             transform: translateX(0) scale(1);
           }
         }
         
         @keyframes shimmer {
           0% { left: -100%; }
           100% { left: 100%; }
         }
         
         @keyframes arrowPulse {
           0%, 100% { transform: translateX(0); }
           50% { transform: translateX(3px); }
         }
         
         /* Step description text with typing animation */
         .step-description-text-content {
           background: linear-gradient(135deg, #1f2937, #374151);
           border-radius: 12px;
           padding: 14px;
           box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
           border: 2px solid rgba(59, 130, 246, 0.3);
           color: white;
           position: relative;
           overflow: hidden;
         }
         
         .step-description-text-content::before {
           content: '';
           position: absolute;
           top: 0;
           left: -100%;
           width: 100%;
           height: 100%;
           background: linear-gradient(90deg, transparent, rgba(59, 130, 246, 0.1), transparent);
           animation: shimmer 3s infinite;
         }
         
         .step-description-text-header {
           display: flex;
           align-items: center;
           gap: 8px;
           margin-bottom: 12px;
           padding-bottom: 8px;
           border-bottom: 1px solid rgba(59, 130, 246, 0.3);
         }
         
         .step-description-text-icon {
           font-size: 18px;
           flex-shrink: 0;
           filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3));
         }
         
         .step-description-text-title {
           font-size: 14px;
           font-weight: 600;
           color: #60a5fa;
           text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
         }
         
         .step-description-text-body {
           position: relative;
           min-height: 40px;
           margin-bottom: 12px;
         }
         
         .step-description-text-description {
           font-size: 13px;
           line-height: 1.4;
           color: #e5e7eb;
           min-height: 20px;
           display: inline;
         }
         
         .step-description-text-cursor {
           display: inline;
           color: #60a5fa;
           font-weight: bold;
           animation: cursorBlink 1s infinite;
           margin-left: 2px;
         }
         
         .step-description-text-actions {
           display: flex;
           justify-content: center;
           margin-top: 8px;
         }
         
         .step-tick-button {
           background: linear-gradient(135deg, #10b981, #059669);
           border: none;
           border-radius: 8px;
           padding: 8px 16px;
           color: white;
           font-size: 12px;
           font-weight: 600;
           cursor: pointer;
           display: flex;
           align-items: center;
           gap: 6px;
           transition: all 0.2s ease;
           box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
         }
         
         .step-tick-button:hover {
           background: linear-gradient(135deg, #059669, #047857);
           transform: translateY(-1px);
           box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
         }
         
         .step-tick-button:active {
           transform: translateY(0);
           box-shadow: 0 2px 6px rgba(16, 185, 129, 0.3);
         }
         
         .tick-icon {
           font-size: 14px;
           font-weight: bold;
         }
         
         .tick-text {
           font-size: 11px;
           text-transform: uppercase;
           letter-spacing: 0.5px;
         }
         
         @keyframes stepDescriptionTextSlideIn {
           from {
             opacity: 0;
             transform: translateX(30px) scale(0.9);
           }
           to {
             opacity: 1;
             transform: translateX(0) scale(1);
           }
         }
         
         @keyframes cursorBlink {
           0%, 50% { opacity: 1; }
           51%, 100% { opacity: 0; }
         }
         
         /* Background blur animations */
         @keyframes blurFadeIn {
           from { 
             opacity: 0; 
             backdrop-filter: blur(0px); 
           }
           to { 
             opacity: 1; 
             backdrop-filter: blur(2px); 
           }
         }
         
         @keyframes blurFadeOut {
           from { 
             opacity: 1; 
             backdrop-filter: blur(2px); 
           }
           to { 
             opacity: 0; 
             backdrop-filter: blur(0px); 
           }
         }
         
         /* Tick mark animation */
         @keyframes tickMarkAppear {
           from {
             opacity: 0;
             transform: scale(0.5) rotate(-180deg);
           }
           to {
             opacity: 1;
             transform: scale(1) rotate(0deg);
           }
         }
         
         /* Clickable tick mark styles */
         .step-tick-mark {
           cursor: pointer !important;
           transition: all 0.2s ease !important;
         }
         
         .step-tick-mark:hover {
           transform: scale(1.1) !important;
           box-shadow: 0 4px 12px rgba(16, 185, 129, 0.5) !important;
         }
         
         .step-tick-mark:active {
           transform: scale(0.95) !important;
         }
      `,document.head.appendChild(e)}}generateId(){return"msg_"+Date.now()+"_"+Math.random().toString(36).substr(2,9)}}const Ao=({config:t})=>{const[e,r]=g.useState({isOpen:!1,isMinimized:!1,isLoading:!1,messages:[],currentMode:"tell",agentAvailable:!1}),o=g.useRef(null);g.useEffect(()=>{const h=t.marketrixId==="demo-marketrix-id"||t.marketrixKey==="demo-marketrix-key";o.current=h?new ze(t):new So(t),n(),(!t.agentName||!t.avatarUrl)&&s()},[t.marketrixId,t.marketrixKey]);const n=g.useCallback(async()=>{if(o.current)try{const h=await o.current.checkAgentAvailability();r(k=>({...k,agentAvailable:h}))}catch(h){console.error("Failed to check agent availability:",h),r(k=>({...k,agentAvailable:!1}))}},[]),s=g.useCallback(async()=>{if(o.current)try{const h=await o.current.getAgentInfo();h&&o.current.updateConfig({agentName:h.name,avatarUrl:h.avatarUrl})}catch(h){console.error("Failed to get agent info:",h)}},[]),i=g.useCallback(()=>{r(h=>({...h,isOpen:!h.isOpen,isMinimized:!1}))},[]),a=g.useCallback(()=>{r(h=>({...h,isMinimized:!0}))},[]),p=g.useCallback(()=>{r(h=>({...h,isMinimized:!1}))},[]),c=g.useCallback(()=>{r(h=>({...h,isOpen:!1,isMinimized:!1}))},[]),u=g.useCallback(h=>{r(k=>({...k,currentMode:h}))},[]),f=g.useCallback(async(h,k)=>{if(!o.current||!h.trim())return;const w=k||e.currentMode,v=Date.now().toString(),N={id:v,content:h.trim(),sender:"user",timestamp:new Date,mode:w};r(A=>({...A,messages:[...A.messages,N],isLoading:!0}));try{const A=await o.current.sendMessage(h.trim(),w),P={id:A.messageId,content:A.response,sender:"agent",timestamp:A.timestamp,mode:A.mode};r(E=>({...E,messages:[...E.messages,P],isLoading:!1}))}catch(A){console.error("Failed to send message:",A);const P={id:`error-${v}`,content:"Sorry, I encountered an error. Please try again.",sender:"agent",timestamp:new Date,mode:w};r(E=>({...E,messages:[...E.messages,P],isLoading:!1,error:"Failed to send message"}))}},[e.currentMode]),y=g.useCallback(()=>{r(h=>({...h,messages:[]}))},[]),x=g.useCallback(()=>{r(h=>({...h,error:void 0}))},[]),m=g.useCallback(h=>{o.current&&o.current instanceof ze&&o.current.setCurrentContext(h)},[]),b=g.useCallback(h=>o.current&&o.current instanceof ze?o.current.getContextMessage(h):null,[]);return{state:e,actions:{toggleWidget:i,minimizeWidget:a,maximizeWidget:p,closeWidget:c,setMode:u,sendMessage:f,clearMessages:y,clearError:x,checkAgentAvailability:n,setDemoContext:m,getDemoContextMessage:b}}},V=class V{constructor(){j(this,"config",null);j(this,"listeners",[]);j(this,"updateInterval",null)}static getInstance(){return V.instance||(V.instance=new V),V.instance}async loadConfig(e="/src/config/widget-atmosphere.json"){try{const r=await fetch(e);if(!r.ok)throw new Error(`Failed to load config: ${r.statusText}`);return this.config=await r.json(),this.notifyListeners(),this.config}catch(r){return console.error("Error loading widget atmosphere config:",r),this.getDefaultConfig()}}getConfig(){return this.config}updateConfig(e){this.config&&(this.config={...this.config,...e},this.notifyListeners())}toMarketrixConfig(e){var r,o,n;return{marketrixId:"default-id",marketrixKey:"default-key",position:((r=e.widget_position)==null?void 0:r.position)||"bottom-right",theme:"light",avatarUrl:(o=e.active_avatar)==null?void 0:o.url,agentName:(n=e.active_avatar)==null?void 0:n.name,enabledModes:["show","tell","do"],session_time:e.session_time,sessionActive:e.sessionActive,recorded_time:e.recorded_time,recordActive:e.recordActive,widget_text:e.widget_text,widget_type:e.widget_type,widget_visible:e.widget_visible,widget_customize:e.widget_customize,active_avatar:e.active_avatar,avatar_trigger_time:e.avatar_trigger_time,enable_widget_popup:e.enable_widget_popup,avatar_status:e.avatar_status,widget_mode:e.widget_mode,mLive_form:e.mLive_form,hybrid_agents_on:e.hybrid_agents_on,hybrid_agents_off:e.hybrid_agents_off,widget_visible_device:e.widget_visible_device,streaming_avatar_status:e.streaming_avatar_status,widget_position:e.widget_position,enable_ai_tour:e.enable_ai_tour,widget_header_ai:e.widget_header_ai,widget_body_ai:e.widget_body_ai,widget_header_live:e.widget_header_live,widget_body_live:e.widget_body_live,widget_chat_greeting:e.widget_chat_greeting,widget_tour_greeting:e.widget_tour_greeting,inapp_login_url:e.inapp_login_url,inapp_login_id:e.inapp_login_id,inapp_login_password:e.inapp_login_password,advanced_settings:e.advanced_settings,themes:e.themes,responsive_breakpoints:e.responsive_breakpoints}}subscribe(e){return this.listeners.push(e),()=>{const r=this.listeners.indexOf(e);r>-1&&this.listeners.splice(r,1)}}startAutoRefresh(e=5e3){this.stopAutoRefresh(),this.updateInterval=setInterval(async()=>{try{await this.loadConfig()}catch(r){console.warn("Auto-refresh config failed:",r)}},e)}stopAutoRefresh(){this.updateInterval&&(clearInterval(this.updateInterval),this.updateInterval=null)}updateWidgetProperty(e,r){this.config&&(this.config[e]=r,this.notifyListeners())}updateWidgetPosition(e){var r;(r=this.config)!=null&&r.widget_position&&(this.config.widget_position.position=e,this.notifyListeners())}updateWidgetVisibility(e){this.updateWidgetProperty("widget_visible",e)}updateWidgetMode(e){this.updateWidgetProperty("widget_mode",e)}updateAvatarStatus(e){this.updateWidgetProperty("avatar_status",e)}updateStreamingAvatarStatus(e){this.updateWidgetProperty("streaming_avatar_status",e)}updateSessionTime(e){this.updateWidgetProperty("session_time",e)}updateRecordedTime(e){this.updateWidgetProperty("recorded_time",e)}toggleRecording(){this.config&&(this.config.recordActive=!this.config.recordActive,this.notifyListeners())}toggleSession(){this.config&&(this.config.sessionActive=!this.config.sessionActive,this.notifyListeners())}isVisibleOnDevice(e){var r;return(r=this.config)!=null&&r.widget_visible_device?this.config.widget_visible_device[e]??!0:!0}shouldShowWidget(){var n;if(!((n=this.config)!=null&&n.widget_visible))return!1;const e=window.innerWidth<768,r=window.innerWidth>=768&&window.innerWidth<1024,o=window.innerWidth>=1024;return e?this.isVisibleOnDevice("mobile"):r?this.isVisibleOnDevice("tablet"):o?this.isVisibleOnDevice("desktop"):!0}notifyListeners(){this.config&&this.listeners.forEach(e=>e(this.config))}getDefaultConfig(){return{session_time:0,sessionActive:!0,recorded_time:0,recordActive:!1,widget_text:{greeting:"Hello! How can I help you today?",placeholder:"Show me...",header_ai:"AI Assistant",header_live:"Live Agent",body_ai:"I'm here to help you with any questions or tasks.",body_live:"A live agent will be with you shortly.",chat_greeting:"Welcome to our chat! How can I assist you?",tour_greeting:"Welcome! Let me show you around."},widget_type:"hybrid",widget_visible:!0,widget_customize:{colors:{primary:"#1BB55B",secondary:"#987ADD",background:"linear-gradient(135deg, #1BB55B26 0%, #987ADD30 100%)",text:"#333333",border:"rgba(255, 255, 255, 0.2)"},sizes:{width:"320px",height:"35rem",border_radius:"12px",font_size:"14px"},animations:{slide_duration:"300ms",fade_duration:"200ms",bounce_effect:!0}},active_avatar:{url:"https://example.com/avatar.png",name:"Marketrix Assistant",status:"online"},avatar_trigger_time:5e3,enable_widget_popup:!0,avatar_status:"online",widget_mode:"ai",mLive_form:{enabled:!0,fields:["name","email","message"],required:["name","email"]},hybrid_agents_on:!0,hybrid_agents_off:!1,widget_visible_device:{desktop:!0,tablet:!0,mobile:!0},streaming_avatar_status:"idle",widget_position:{position:"bottom-right",offset:{x:20,y:20},z_index:40},enable_ai_tour:!0,widget_header_ai:"AI Assistant",widget_body_ai:"I'm here to help you with any questions or tasks.",widget_header_live:"Live Agent",widget_body_live:"A live agent will be with you shortly.",widget_chat_greeting:"Welcome to our chat! How can I assist you?",widget_tour_greeting:"Welcome! Let me show you around.",inapp_login_url:"https://app.marketrix.com/login",inapp_login_id:"user123",inapp_login_password:"encrypted_password_hash",advanced_settings:{auto_open_delay:0,session_timeout:18e5,max_messages:100,typing_indicator:!0,read_receipts:!0,sound_notifications:!0,vibration_enabled:!0},themes:{light:{background:"#ffffff",text:"#333333",border:"#e5e7eb",accent:"#1BB55B"},dark:{background:"#1f2937",text:"#f9fafb",border:"#374151",accent:"#10b981"}},responsive_breakpoints:{mobile:"768px",tablet:"1024px",desktop:"1200px"}}}};j(V,"instance");let Re=V;const z=Re.getInstance(),re=t=>{const[e,r]=g.useState(null),[o,n]=g.useState(!0),[s,i]=g.useState(null);g.useEffect(()=>{(async()=>{try{n(!0),i(null);const W=await z.loadConfig();r(W)}catch(W){i(W instanceof Error?W.message:"Failed to load configuration"),console.error("Error loading widget atmosphere config:",W)}finally{n(!1)}})()},[]),g.useEffect(()=>z.subscribe(W=>{r(W)}),[]);const a=g.useCallback(()=>e?{...t||{marketrixId:"default-id",marketrixKey:"default-key"},...z.toMarketrixConfig(e)}:null,[e,t]),p=g.useCallback(C=>{z.updateWidgetPosition(C)},[]),c=g.useCallback(C=>{z.updateWidgetVisibility(C)},[]),u=g.useCallback(C=>{z.updateWidgetMode(C)},[]),f=g.useCallback(C=>{z.updateAvatarStatus(C)},[]),y=g.useCallback(C=>{z.updateStreamingAvatarStatus(C)},[]),x=g.useCallback(C=>{z.updateSessionTime(C)},[]),m=g.useCallback(C=>{z.updateRecordedTime(C)},[]),b=g.useCallback(()=>{z.toggleRecording()},[]),h=g.useCallback(()=>{z.toggleSession()},[]),k=g.useCallback(()=>z.shouldShowWidget(),[]),w=g.useCallback((C=5e3)=>{z.startAutoRefresh(C)},[]),v=g.useCallback(()=>{z.stopAutoRefresh()},[]),N=g.useCallback(()=>(e==null?void 0:e.widget_text)||{greeting:"Hello! How can I help you today?",placeholder:"Show me...",header_ai:"AI Assistant",header_live:"Live Agent",body_ai:"I'm here to help you with any questions or tasks.",body_live:"A live agent will be with you shortly.",chat_greeting:"Welcome to our chat! How can I assist you?",tour_greeting:"Welcome! Let me show you around."},[e]),A=g.useCallback(()=>(e==null?void 0:e.widget_customize)||{colors:{primary:"#1BB55B",secondary:"#987ADD",background:"linear-gradient(135deg, #1BB55B26 0%, #987ADD30 100%)",text:"#333333",border:"rgba(255, 255, 255, 0.2)"},sizes:{width:"320px",height:"35rem",border_radius:"12px",font_size:"14px"},animations:{slide_duration:"300ms",fade_duration:"200ms",bounce_effect:!0}},[e]),P=g.useCallback(()=>(e==null?void 0:e.active_avatar)||{url:"https://example.com/avatar.png",name:"Marketrix Assistant",status:"online"},[e]),E=g.useCallback(()=>(e==null?void 0:e.widget_position)||{position:"bottom-right",offset:{x:20,y:20},z_index:40},[e]),q=g.useCallback(()=>(e==null?void 0:e.advanced_settings)||{auto_open_delay:0,session_timeout:18e5,max_messages:100,typing_indicator:!0,read_receipts:!0,sound_notifications:!0,vibration_enabled:!0},[e]);return{atmosphereConfig:e,isLoading:o,error:s,marketrixConfig:a(),shouldShow:k(),updateWidgetPosition:p,updateWidgetVisibility:c,updateWidgetMode:u,updateAvatarStatus:f,updateStreamingAvatarStatus:y,updateSessionTime:x,updateRecordedTime:m,toggleRecording:b,toggleSession:h,startAutoRefresh:w,stopAutoRefresh:v,getWidgetText:N,getWidgetCustomize:A,getActiveAvatar:P,getWidgetPosition:E,getAdvancedSettings:q}},Nt=t=>{switch(t){case"bottom-right":return"bottom-4 right-4";case"bottom-left":return"bottom-4 left-4";case"top-right":return"top-4 right-4";case"top-left":return"top-4 left-4";default:return"bottom-4 right-4"}},Eo=t=>{const e="bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700",r="w-[360px] max-w-sm";let o="";switch(t){case"bottom-right":o="bottom-20 right-0";break;case"bottom-left":o="bottom-20 left-0";break;case"top-right":o="top-20 right-0";break;case"top-left":o="top-20 left-0";break}return`${e} ${r} ${o}`},Pt="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHAAAAByCAYAAACLKFVAAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAALEsAACxLAaU9lqkAABPXSURBVHhe7Z0PbFzFncfn7TreBIzX6aWxSYLthgAJNDi6KFyBgg0JbdWqohQl0Koid0TcgWghECRKpYY4kaCcqI40RVe1lSjpqS1wJW1PVekpLTjXu6qpQmNRaP5wwTGhOHBRvfnTsCHeud/3t/N7nn37dr1/5u0uZD/R5M2/93Y9X/9+M/Nm3rMivAcffDCmtfaQQFqCyZMQQz0cTeA8O71y5cp4IC8n4HxzDf9cKw/nxnENc52cEMy3z5Hy/v7+Foq3LF26dBqOEiQfAfVQbq7l15U8+1z7PBNQlhNM/Wmm7rSLL7641S4PBK5jnyNxCUgHrxkMyMfnmHqTQgUE80Og0fkYFKJInINpMI6bc23xEKTcF8Q+SlxCWBkduaELxa3AeSKQHCWEpU1jIZ3TmHaQhpcjglzLysu7RrBMPivsc0Ou7QunLCuUuKS5DoI0uGkYafycYInCwVwLcTlyCNYzAdcVQThtvijnS0C59Qsg+dL4wXPyREGQxsG1AueF1Qs2IMr8/GCwz5G05MnR+qycfLuuCVwnmA8r9MXzvKxWlOYjkDwD6nIh5XMBNR4OzODgoIkpTQ0So4tz3VdeecV75pln/IvKOajfPm9ehzfR1qsyuk9pr0PFMr10TFJxBwePgua4D310j4lGg1bjWumUSQkj/L/npaiBUDZC8XGlTo9qFR+5YG7b8K5du7gKoJ/do5+bf2YSSR8/ftxvSKonbcF5JAjn0dHDNUyaKwiSZ19XYIuixswUEtKk8R8ysoUEhBDRTNwvh9CrVq1iEVFHypOdFw2omNdHgg14yutngd4nkOjD9N8wxXbozMTQ0bf/96ApErh9igkkYltC+m1qn2fFs26RsMVBHEgaRz9PhLNEYyjtIZ+wr6Xa28nKZpx9Nwl2F+W+bwSbCmrXHfT/1tThfVtNVg62CJxBUB63W1AoHIHk2+AEv7EhwoYNG6CoLQK7Tspngcg9emJZxUh2XjhAp66na/WbrDMSarqD1II/y5w+veXCnpkjQRFgdUNDQ74GgpWfYxBEjrtFQU4hAYvkOAUpy6lDwbdEg9TVyTmLlqiJzL+c6cKFME5tu2XCS205PjZG/aeP3862xYVZG/rAGTNmoD5DdTRGcDnA+giT4otLYHXpEBQTeHPmLJyZ7Fr4mJfRLzbFC6WD2uWrcZ38PXmnWyASAuG3p4hmi2fqMBjAoMwq9/IEJOhzPIiFC3MQQZEfgDNocNJ/YkLvosRdnNukINSGPZ4X++6rh45/d//ouD+itoWyscUEIrzks4CWxeUpBKCoWB9cp7hPHEk89HO/xhfL1m5SCtRet3ixlu3JcxdeivTJkye57UWgAOj3THQS5IlgbGV0UcSDbtIHgxwcIV539+JkKn1qG53TdJdVQm2/KXV47yYMXJDG4EWsTI6oRuVchgTy29rasm4yRDz/SFCRKTSJzu5Le95Jp5+naNPqHEFN64sIkaxJe6hBSTkK8goFuiiE1WR57GphecnZF/R6sfivKNmLvCbuEBFNkhHXafeFVp4/kUc6aHWSB1jopnjRAxGXLOzaGDY3JGxr1GSFMX8UCtFMVMQDLBwiye7uJA1af03RpngRQm3/1d17xtabpI/pH6EFjiweXGjONEIGKTYkLAd16qwn6OLNPq8GQMTk7AtXmyRAv8hHChjg+De1bRcqiNKA4zRVeJDqTC49NKkF43GlrzsytnfYpEW8nP4whnucdCQdWVBgqwnxBpri1YWO01r9e1tXFy8AwOrowHdiBIiJTFuwHKjf61DpGX8gAZuus06QWW1ZMPfsdTIXpJCjV1gfKKaoqd+D62yKV0dIkC+9+vqxqyeTWTCo8S0Q7tP0gzznw5JSV09fb/rUqQPIbFJfSJ8dND9cYZI5BAX0ob4Po057JNSkjsSUXvmhuW0/tftAgA1HLB7cpxnI6M7uS3ub4jUWE1o9aosn903ZAilw5yhiRml9V16+TH3+phtMqnp++PRP1G/+Z6dJuef2225Riy9ZaFLV863vbFUvvbzHpMpDZzIrUm/t24EoBXaZ4jd98To7L+1Ne9H2fTu2b3PWKKOvv6GuXnGDSh09ZnLc0X3eXDW8c7tJVc8Pntqm7lz7FZMqH9JoiPrC6xA10woehbIFQjzwjkpHPuf7wj980VmDo5Hvv++LJuWWf3vimybmhke+/riJVQZp1P+BOYv6IR7cKQIE9M2RgJCRr+/Bah551F3j3EFu7qNXXGZSbvjcTZ9x6johHn7uapmYyFxt94UQbrLvm3NBn5eJ/yFbFD3/8eMnnTW8S1cKq8Z3w9EF+G59l4XOAsqGtDpIbnQB4rBEbE0n7dgAtdLxAURqBfoDl64UAw4X3H/fnc7EA+gyXEFa9XR1LZiJKFbk49ZdbjX97L/5GlWo2XIRxEun02r5NVeZnOqANWNUWs0vBVznl9e5a3AMXJ74/lMm5YZ3tdqbPnFk+ODBgx7PAymwCXrK6+MaNeRfaVjtchrw+GMPmVhluBSP+/oqBy6heKpPbqXF4D4p6GT34plUUJet7y5dKaywUld6/zq3rvORR90MXPKJdcNz+qNQtsD0qSXZwtrDv6kOR6VfpmlFuUKgPs5zBbzKD57eZlKO0RpasdfkZ/dghWSLdX3wBK70589hu031JNvPKduVYtTpkmom7FNBevkrROxCCc3P6NWZO+9+wKkr/dQnlptUceBynbpOR3O+Ypwzaz4PNnkagSUkkrXuj35BPIjoioc2PsDWWAzXrhPCfc1hd1CI1pZpeBBW8TQCgaYQN5M11q0fFPa/+ppKJtvVsqXVOwRcJzE9oX71/G9MTj4PbXpALftbd84HrhM/Q9RkMvppmkqM8DSCQEfYMCvvGNC4ckHFbrNhzvf5Ve5WRjDnc9WPT4mnenlfqOkDcTuNI40Au1KHgwAMaIKulF3ne2HOVwTZF8omSELysVHAMBwjUxdArODc0PnAJbI5XwG8GPeBsDq2vGTnRa81khsFsBqsHbpqaNxQRiPjei7X+XBNVzerS4U85qYF89o2+RbYiEThSoHrOd+nb6zf7hMIGLqlvlFw6UoxmHG5TARqMecrxC48nYQIBjAzz12EbRQN+eCKa1fqinq4TkGrzJbU2L57YYHU9bGODfvUEVzpF251N2J0BQYudSP7RqvQlxw0JC/9cU9N7nCUCuZ8kd2sLg22uveMgAD9TaVb8lwC11nrOV8hWEBzN+Y9gcsdbZWCvZ31GrhYsGh4FSOI/W7Xy5FtJ0y0J1TPwALVtXSeap/XoeLTW9Rf3z5hSssD4rnchlEuEG7NHetMqq4Mp08c+ZlMH7yOroUZE3fG3Mt71GX39au5V+SPj46+Pq52Pjqk9jwtzy+Wh8sdbeUgNwPqDXnN76cO710jL2N1zmXr+tUNz64OFQ+0n9ehVmy+Xt2y8y51znl8V6gsXG7DKJUGcZ3C5J4Y10A8WF4pQMgbfrya3Ww58ECihqNSfF4jjYIB74lxPYBZdFNfyeIJELHcc4DrHW3FwJyv3oOnMJxb4DKyvkrou+0jatYlnSZVOrVwpQ0w5wuFXSgirqxw7uW9bE2VMv8T5T+LANf2lfUPm5R78MvRKHO+ILgXCgH9J5OqZdaHy7cgm1kf7jKx8ohyJRzXbqCBSx4Q0JkPTbRPN7HK+GAFLlRwuaPNptSdbfWioW6lpY++Y2LlA/FcPkQiYAUEO7YbEX46Cf2fqz7w2CH7VdDlc/T14J9rKA+Xa4c2d/zj6oZbygLUB2bk2QiTVR0HfrHXxCrjwC+qv1HtckebUMlO71rQ39+ftUBXwAUeeK4yEXFr7bXnqhcQrtTlNgyhnJ3etQL7eZ3PA/9r/S8r6stwXzR9NG1ShSnljk1UrvTxzQ9PudO7lnAfaOLOOEaWtO3GrWWJuPPrpd/U/uimj9N88SKTKkxUrjSqFypUAveBJu6U//vjmPrRim+zWywGRIbFwvpKAbfpFq1aopZvvn7KG+BRudIoXqhQBR7WA9mHTm+b5XQ98BSJM/yd3/HINNE+QyWS01VLooVFO7zrEFvcf97+rHrjt8G/ERUOXOfHvnWjf50PXnLulFYLC3T1nIXN4ksWOX9sugIm1wNpIINdac7XA10StsIB68UvyVS4fLGQ8MD6h3l5qV6QZluXLOxaw3diXA9kXAN3GbZagbxS1hLvXOvukTWhkqeAXcOjUBNvaLBeGAZu3a147DMmVRjsaHN9w7tB5ob+wy2a/lV3GyUi+m77u6IrHHOv6OE6UxHF2iEGM3Uc0EA3nkbAf3qkYHX3sSIA7rEUceBKS1lLjGLtMOzRtRrBoz92oS7vxrgEwpSyvph1pdebVGEwKnW9DYNvdtdxbsi30hpxECNzvlLBWuJVGz9mUoWJwpVibuh6lFsCLFpDDmIw56tkawa2ZaBPnIooXCleqFBjeOzi3wulY/RP5pcIhKh0a8ZycqVT3S+NwpViMOPqZXsl4XnjK1eubLw+sNCcr1RK3eEWhSvF3LBmAxqtU/j7/NIH0kGXdk8rYgrN+cqhXq6U54abo9tglUPWAj24UIjXEKMYDFyq2dVmU6ordfliIYA1w1rMDVvisXGyQOtdaUqNcEmdgOusdE9pIUpZX8RuNtc72moxNzydyfCNF7ZAzol5db0TU+qcr1SwJlkqsEKXa4eYG0Y9oDlLZUZlEGPcp1c3Cyx3zjcVvIw1xVqkTRRrhxHf7B5/8819f2EXSomsBXrv1m0Q49J1ymNr5RLFNoyobnbTuJO14k1N/KZCcOJUXSwQ63wuXWd2b01l+0tdb8OIbm6ooRX+qqc/+sRQVHV0Lazp25owcFm9826Tqp49Tw2r7Wt/alKVgUZ3+SIguOe+ZcudTlfIZd6bGtvzDcTjZgrhXXPNNdhWsYQErNkrJ2/e/k+8RcIFsLpf3vEsb+WoBligy20Y0xOJKV95WS40hfjnk8fezq5GYAoxODjI99XiKl5+51EhLud8AK6znIFLMVy7UtcboRI6428GmhzEkBVOvHP8JyYeKa7nfBi4lLI3plSiGJW6GtCQxxy68srF/m+qvyuN0Ol0Kk1uFC0b6Vubrtr0cTWvwLPzlfCj675dtesM4tqV4lrgv3/7ez5WwaYXd+5gC+R5oPWiOz5Sj1jdKGAK6j3nKwfso3H5YiEnD8nozAsmpngeiP7PiMiutKM18T2KRXZXphHmfOXgckdbtRuhyH0+mXpr/0HSS8P6AL9qGQMZgKkE4lH94X9sfaj0KdwwIGBU1meD1XZxgS6odBlLt06cnxrdz6NPiEjGx8qJC/VJdi/u8NLvHqASd8PEJlXB1nd4762Ik3icRwL6WypkJMpWmBp96S9a6c0mq0kDkEi0bjRRFk4ItUDQTVZ49NS7L1K0Yd8jeqZgWx+SFFgzWCJHpB+E9QHpE5PnLrqeOsnGe0HKmcWI1plr197+Oe77YH0Qzlghb6mAeKwcjiZO2eRK3/wTJvY1mdw3CYd0GIR4EMx2nULQfSIN8XxRyZXObLrS+kCWtzl1eN+9JpmDWKEMYgT2r0Q2RYzSgCYej4v/bVI7RvS0v26UEaccBbHGoICAXSgFqMjzxCNvvPyC9jL3oLBJTRjRmYnlRw8dGpe+Dv/ZIko86EJ9IByOxhpZ0Kgm+E0stBrXce/a1J//VPDxYxEvzIUGhQNijYqGshuoPL8nbeIGSzyIJEJRm+dZoFhmnoAkHFcmZETKcXMNNT62Z7ApYgRMircbSQiEIKLhaLtTAE3C+sBQjJhsiU0RnTNiuU38RdUca6O294x4DMWxAMH58tb6opBYuID4VN5+kT5xZChx1gfGPeV9hGR1sy/ijETvpvb9ZGpsL9atuI3lr6paVudDeR6VeQMDA2r27NnWfKEAEI/wrQ/AdAHlq2TnhTQ/9J6neEP96br3AlplNp/T0rLx0KFXii2p+G0fJuiULhQiASNaVjkC+cijiebI2ttvnk/xpkstFfR3mYnPpsb23bNmzUpfPAiEYJC2LmpkpfSBfCFYIcHbD22Q3rBhg6YR6mBr67TzKauuz1g0OrC6zLTj56fe2s87H2BRlmiMSYtw3N8B6fuAHIuqK0A4sURAJ6NPhKCcJgE9iCh1aL64muL4hObtNwO11ZDSmVtJOPkFL2pheHQMz/8hbgmIA/JwDh/LERCC8ZGy+DwISGlEw+KahPx7OuKBvwEuONOAq/QyW1Us/r3AxNxvQwvOs60NaU4UoaRphBHNF0iA5Zko14FwFh5NN56kcG2itXU+XAcpy3Oc9zUkGv3/gs6oe9oT0+ajn1t726qcuyqmncQdytEXz5AnHsoR7IaeUmFA9bmeJWDobweuG6xDH8juNpsF90qjVq366OwBz4v10UkddFLNdoM7hcXSI/TDDauYt1tl9LBKnNydGh3FO3ekjSCQ3yiWG2RM+5hUViS0l9Vuee1s4LJChVMCUYMWKb8YsEYcOEEEhBXkh+ACcrc9LS0tH0L89OnTvfF4XE3oTJIaZXJfjqc7PBVLms/m88PiwTwcBckHdj0byg8+qYV+y6PvpCcmJqhMjyQTifHR0Zd4BEn1/Z8v0PB51yY43zrHrxcU00KuxxiRTao0+GT8wJzKgrgf6KJwxzl5JgicNtfwjyF5QK7HcasuyDvHKveDfS2EQFoIqxO8Hgj9jEL5hfJMPgTw28rk8VNiJr9YCKtbNvwlzDHsyzLyheVLG3LqBs8NnJMX5AcPlpv8nIaRUOhawRBSD+Sk5bsVuqadX6hOWLCvGTxSEKH8MCmgiv0/8+gzwP0KrEwAAAAASUVORK5CYII=",Co=({config:t,onClick:e,isOpen:r,agentAvailable:o,isScreenSharing:n=!1})=>{const s=t.theme||"light",[i,a]=g.useState(!1),{getWidgetText:p,getActiveAvatar:c,getWidgetPosition:u}=re(t),f=p(),y=c(),x=u(),m=s==="dark";g.useEffect(()=>{const k=setTimeout(()=>{a(!0)},2e3);return()=>clearTimeout(k)},[]);const b=x.position||t.position||"bottom-right",h=Nt(b);return d.jsxs("div",{className:`fixed ${h} transition-all duration-500 ease-in-out ${i&&!r?"transform -translate-x-64":""}`,style:{zIndex:x.z_index||50},children:[d.jsx("button",{onClick:e,className:`
          relative w-14 h-14 rounded-[27px] gradient-border transition-all duration-300 ease-in-out
          ${m?"bg-gray-800 hover:bg-gray-700 text-white":"bg-transparent hover:bg-gray-50 text-gray-800"}
          ${r?"scale-0 opacity-0 pointer-events-none":"scale-100 opacity-100 hover:scale-110"}
          border-2 ${m?"border-gray-600":"border-transparent"}
          focus:outline-none focus:ring-4 focus:ring-marketrix-500/20
        `,"aria-label":"Open Marketrix support chat",children:d.jsxs("div",{className:"w-full h-full flex items-center",children:[y.url||t.avatarUrl?d.jsx("img",{src:y.url||t.avatarUrl,alt:y.name||t.agentName||"Support Agent",className:"w-full h-full object-cover",onError:k=>{var v;const w=k.target;w.style.display="none",(v=w.nextElementSibling)==null||v.classList.remove("hidden")}}):null,d.jsx("div",{className:"w-full h-full bg-black rounded flex items-center justify-center",children:d.jsx("img",{src:Pt,alt:"Marketrix Icon",className:"w-12 h-12"})})]})}),!r&&i&&d.jsxs("div",{className:"absolute left-16 top-1/2 transform -translate-y-1/2 px-4 py-3 bg-white text-gray-800 text-sm rounded-lg shadow-lg w-64 gradient-border animate-slide-in-left",children:[d.jsx("div",{className:"flex items-center gap-2",children:d.jsxs("div",{children:[d.jsx("div",{className:"font-medium",children:f.greeting||"Hey! 👋 I'm Marketrix AI"}),d.jsx("div",{className:"text-gray-600",children:f.chat_greeting||"How can I help you?"})]})}),d.jsx("div",{className:"absolute top-1/2 right-full transform -translate-y-1/2 w-0 h-0 border-t-4 border-b-4 border-r-4 border-transparent border-r-white"})]}),!r&&!i&&d.jsxs("div",{className:"absolute bottom-16 right-0 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-200",children:[y.name||t.agentName||"Support Agent",d.jsx("div",{className:"absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"})]})]})},Io=t=>t.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),To=t=>{switch(t){case"show":return"Show";case"tell":return"Tell";case"do":return"Do";default:return t}},No=t=>{switch(t){case"show":return"I'll show you how to do this";case"tell":return"I'll explain this to you";case"do":return"I'll do this for you";default:return""}};var jt={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},Ot=g.createContext&&g.createContext(jt),Po=["attr","size","title"];function jo(t,e){if(t==null)return{};var r=Oo(t,e),o,n;if(Object.getOwnPropertySymbols){var s=Object.getOwnPropertySymbols(t);for(n=0;n<s.length;n++)o=s[n],!(e.indexOf(o)>=0)&&Object.prototype.propertyIsEnumerable.call(t,o)&&(r[o]=t[o])}return r}function Oo(t,e){if(t==null)return{};var r={};for(var o in t)if(Object.prototype.hasOwnProperty.call(t,o)){if(e.indexOf(o)>=0)continue;r[o]=t[o]}return r}function xe(){return xe=Object.assign?Object.assign.bind():function(t){for(var e=1;e<arguments.length;e++){var r=arguments[e];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(t[o]=r[o])}return t},xe.apply(this,arguments)}function Lt(t,e){var r=Object.keys(t);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(t);e&&(o=o.filter(function(n){return Object.getOwnPropertyDescriptor(t,n).enumerable})),r.push.apply(r,o)}return r}function we(t){for(var e=1;e<arguments.length;e++){var r=arguments[e]!=null?arguments[e]:{};e%2?Lt(Object(r),!0).forEach(function(o){Lo(t,o,r[o])}):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(r)):Lt(Object(r)).forEach(function(o){Object.defineProperty(t,o,Object.getOwnPropertyDescriptor(r,o))})}return t}function Lo(t,e,r){return e=Bo(e),e in t?Object.defineProperty(t,e,{value:r,enumerable:!0,configurable:!0,writable:!0}):t[e]=r,t}function Bo(t){var e=zo(t,"string");return typeof e=="symbol"?e:e+""}function zo(t,e){if(typeof t!="object"||!t)return t;var r=t[Symbol.toPrimitive];if(r!==void 0){var o=r.call(t,e);if(typeof o!="object")return o;throw new TypeError("@@toPrimitive must return a primitive value.")}return(e==="string"?String:Number)(t)}function Bt(t){return t&&t.map((e,r)=>g.createElement(e.tag,we({key:r},e.attr),Bt(e.child)))}function Me(t){return e=>g.createElement(Ro,xe({attr:we({},t.attr)},e),Bt(t.child))}function Ro(t){var e=r=>{var{attr:o,size:n,title:s}=t,i=jo(t,Po),a=n||r.size||"1em",p;return r.className&&(p=r.className),t.className&&(p=(p?p+" ":"")+t.className),g.createElement("svg",xe({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},r.attr,o,i,{className:p,style:we(we({color:t.color||r.color},r.style),t.style),height:a,width:a,xmlns:"http://www.w3.org/2000/svg"}),s&&g.createElement("title",null,s),t.children)};return Ot!==void 0?g.createElement(Ot.Consumer,null,r=>e(r)):e(jt)}function De(t){return Me({attr:{viewBox:"0 0 512 512"},child:[{tag:"path",attr:{fill:"none",strokeLinecap:"round",strokeMiterlimit:"10",strokeWidth:"32",d:"M87.48 380c1.2-4.38-1.43-10.47-3.94-14.86a42.63 42.63 0 0 0-2.54-3.8 199.81 199.81 0 0 1-33-110C47.64 139.09 140.72 48 255.82 48 356.2 48 440 117.54 459.57 209.85a199 199 0 0 1 4.43 41.64c0 112.41-89.49 204.93-204.59 204.93-18.31 0-43-4.6-56.47-8.37s-26.92-8.77-30.39-10.11a31.14 31.14 0 0 0-11.13-2.07 30.7 30.7 0 0 0-12.08 2.43L81.5 462.78a15.92 15.92 0 0 1-4.66 1.22 9.61 9.61 0 0 1-9.58-9.74 15.85 15.85 0 0 1 .6-3.29z"},child:[]},{tag:"circle",attr:{cx:"160",cy:"256",r:"32"},child:[]},{tag:"circle",attr:{cx:"256",cy:"256",r:"32"},child:[]},{tag:"circle",attr:{cx:"352",cy:"256",r:"32"},child:[]}]})(t)}function oe(t){return Me({attr:{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"},child:[{tag:"path",attr:{d:"M14 4.1 12 6"},child:[]},{tag:"path",attr:{d:"m5.1 8-2.9-.8"},child:[]},{tag:"path",attr:{d:"m6 12-1.9 2"},child:[]},{tag:"path",attr:{d:"M7.2 2.2 8 5.1"},child:[]},{tag:"path",attr:{d:"M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z"},child:[]}]})(t)}function zt(t){return Me({attr:{role:"img",viewBox:"0 0 24 24"},child:[{tag:"path",attr:{d:"M12 0C5.383 0 0 5.383 0 12s5.383 12 12 12 12-5.383 12-12h-2.7c0 5.128-4.172 9.3-9.3 9.3-5.128 0-9.3-4.172-9.3-9.3 0-5.128 4.172-9.3 9.3-9.3V0Zm7.4 2.583-7.505 9.371L8.388 9.08l-2.002 2.436 4.741 3.888a1.573 1.573 0 0 0 2.231-.233l8.504-10.617L19.4 2.583Z"},child:[]}]})(t)}const Mo="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATMAAABOCAYAAABMk/H1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAALEsAACxLAaU9lqkAAB8CSURBVHhe7Z19iB7Hfcdn9nnubk863Z1svZzTq080iXQJIhE0OGoIlhpMqyYhFm5xhJM6ChTHmGD0RwhGDWkSgiqCKa4oRgRDHdMG2X8EOaRBDiZYxg1OSEEOjntS5HCnXqLT+z2nO+l57u7Z6fzmmd/j2XlmZmf32efetB9YdmZ2XvaZnfk+87azlCST5IfxA/3YzL6Y/GeJRwXCQhydJu900vxu9JsmfTWMnk7SNSRtmkjWcAUFVgJ5RtSCC2a90OkFEOxqGBV0t11HXP7U+LMWft9wSfeZhE86tjSSwqrXbX59fyfiyncA4lOvmeJPmyaSNVxBgRVdzPRCptv1gm+rCCoYh6vSuEgKnxdJ96GT5X5saahxgR/0p/sHO/i1XU+DHocaF6Sh35OabkHBikMXMxUswLZCbHJTK4COqyLoFQfPrvSXA9N95o2aBprVPNDzB1HNacC41fD6b1PTd9HOPRQUtIVLzNQCrBc2vfCrmCqCDbiG1yGcGlYNp5rRj54O4kqvXWxp5oHr9wNo18+2/EjKB/U6mNV4VLuOKV50s4VJImu4goImpoKJ6AUUC7jpHGN4eDi8Xu0b7KLBVuEQ1AfFmUUbxTlHgoDejhitRWyxGkTdVRIsVtaVZqcuXrxYlV508L59Ses/C2r8LfnJ0fNZtev3pt+v6f71+BCbu4oeV1ZM91VQkJmkgovX1UKHhTAWdmDrjpGAstEoCkYJZQ3xWkYYYVXCggkaLY6x+erEzMzktLyUhU5XPIxbfx6Yzy35bSDt/an+24m703lTUOAFFmJTgcRr4G4s7CMjIz3T1XA3F47dlNBQOq9MWPQWqdVeq1QuVKSLD2kralr/Puj5b3oe7aSJYY3PWIJputLpxG8vKPDGVIDVQonX1cIs3DZsef9uSkt7VryI6XBRY9Xbp3lLDURNrXzq704ijV8fWvKXo7up11TAPS0Yxpamju6noGDFYSq4KnoBpgMD9w6SsPdBbt7WcFqFMDZNouh05er5t6TLSkMXFV1MwGw6+6CHM6HGpfvV0zGlbXIrKOgotsKMqIWS3n3P9h0LEdm/6lpjFiLKfnlz6twr0toJ0lRq8Gd7HrZr6O6bho4rTR1XGu3cQ0FBLtgKcov7wNYde/lpT8O2dggomQrpzAuO2c+VgCoU6rNBMcLreC2LsGBcSWSJu6Cg45Tk2USzYK9VIQN4zeyrk573b9zQ/dvZ2dlF6ZwHPsKQhCpSeKiAXfWTRmjArxqfHjei+ksTf0HBkoKLZq2FGgb6+WlNChkSMTJ0K+r/vLTmRdaKr4aDZ6EKiXoNzehHTy/2HA3o19X49bjwWlKcPqhx5BFfQYHA1DLDAiYG+2lXzxekfa0z2L3h7nB+9tq70r5cQP6bhAPsqptqVsVHD2cD00gK6xtfOyxFGgVrHNPrTFi4GekJvyTNdwQBox8f2PLB5ZilVQUFwMr93rMwn024rqmgkGFaaNfd1LOKyS0tGIfvPRcUWFHFTC2cVIyTUbrsK/mXHvq5e+65J81sbV6VGoVEBePG67pdDYPXsqCG1eNR01AxuQEQ3vdebHEUFKTGWOgGBkYGSRgektY7kdOVS2dPS7MNyLu8KiPEg/Gpz8TmjqjXs6DG65OWippulnvIEqZgmfgn9u/hAivvYjQYAjslbHyOLIz/K/1yO68J5goW2ljBGtiyfT9vle2S1jsORmh1fVA5dvHixZqwpqPTlRTixjTw+fmkp/q3YYpbRb1ecIdwmP3HLkroPm6M9VgYo9PztHziafrwlHRaVloKbLutsp/86AXyyU/cJ23JXJicJJ/81ENkZmZGuvjz6X0PkB8+/2/S5scTTz5FfvjSSWlzAq2z1/lZr7imypylgqth8NzyPBTAj+l62nR11LRtaajY0lN/z5Igy6rtT3ecP79xaS7ICG+RDS6SbpceVMtk/plv0y8v+zrNlgmAqKdrVBozAWIxPe0vTPcOD5MnHntU2tJx9LtPSZMfFy5M+goZr5X04+LUiq9bEnoYXQzQDGc4dJHRw6uAX5MomcKgP1MaiCstxMdPvoQhjOnCGkjTsXpft1tB1Fk3tMhchIukDMu3lp0WMaNBqa3u5YXJP5LvPZ2utfTU177KRe190uZHI8ywtPnx2Yf8RZMSFnZwZtMmGgCKAvhRzYAuGLpd9adfA2zpJt2PGq/Lb8Eag9HkPwX+x78i/jhiYgbNdsqIGOBrh2efe4G88YtfSZsfzx47Kk3JgPCBmKXhKBdYENo0RKTU2FyyQbuVWA1vEhoE/OF1MKvhbPeA7q54kzDFYRIv3zRs91pQ0BHiLbNGsz0X0nY3YZzNt7v5k5MvSJMf0L189vvpwgC8Nqr/OO0IBeAKjxVfPYN/NYxuVsXCFXca9HjRnCX+vO6pYBlhhCUO7lMWrYgJAL2bmVtzsVPdzUcefih19xJaZVkmGGiJqC0zQK3oeQOVXxUASAsOdDOJTJb70UVGT9eG6T500t5Plvu/Y+i7Z/vowOYP79KPu7m79NJx5kn3KWk0AjOas7T+prQuKzExY5TlurUPdDd/eupVaUumv7/f2d0U3cuvPyFtfvzwxEnvQf8Wopbtv30qdDtgvKq42NLyESATanxqHGA2pQ+AOx6udNPeU1r/dxSlerCPBPX9+rFIuPsSAcsuIkJOcGPLbCUuzVgpa81QzEQhpoy2PV6m8/iTh1N3Nz+77wFpi5N20B/SPfr0MWnLRn//sKnr7VMJURh8cfmH9NQ00ZxGDExhUKDwQMCsp5cmrTSo6RasQP6ZfmGsTOaPMxad4sJ2Bg4wd9Ha8ZWyxgxAMetUQRXduycOHZY2P4589ynRSlOB7uUjBx6SNj++9y/pB/1zJE2e6sKBoBkrPNjV62mEwCRQeFbdETVN1WxDvxffe3PFWbBC+DZvfR0J/v5NLmwn4QDzSlhbphIfM2OdeRcTuprHUwzAQ+vrsDJbCcKWtnuZddBfh4a9HckTDbXigxntcNYru+o3jRCgKKlxq+d2wfiRQqQKlhR9AqBjHIGlEVxgfHn8sUebbxKAsHVyTdky4FPR0Q8IhOpfD2sTI5s7hoezHq/qhuc0YpclTEFBLsQK3cCW0UOd/OYliBO87uQLvOr0xUe/Sl7/eboBfJh4OPyNI9LWHnVaf2l26vyYtOpA/mEFtgK7cNyq9zXGIyl9z3+1Oq1++m5g6/aRiNWHAhIMERoMgBtjtMbIwnhQWxjjfq0DrbD3HLy9EQtLaJXWF8+ShflxJSyk7ys24l5HRkbC67e7dkHcjAYhLChuXOTxN6bu4dWhCXCTOPME4puuhq3jsyI/JmK/sek3Kg2SoD6tvqI0sHUHzL4fbNhaeI37fU2aW1i3+cNDXUHdOuHl+yoUrM2EfC8HwWCdBYN63pQDNnXt4jlb+Ykhf08TRtgB4/c2AjpNItZSKRaiUvXWlXdiY1jyla+WOj0YVqcmJiZi3UTI69n5nm2Li+WQzM/xMtN4FtbnxTHFo/8OHZ+8zfJ84mK2dce3pLFjHP3OYdHq6hTQ+oNWWW5jZfX6y/IrTl7CZQJEigc37Q0nducYHh7umVnofZCSwD3lztiZDd23XpmcnGwWHhAxFvb8dWLYRuXWdwJBYcPfheVBuK/bdO9QV6n3r7k5eckOfPGK0jM8DauAcERaNhEKaOnNG1PviKUAohL29OxllIw2KzT//ZXL55qVOKuYbdjygd08LdeMoFMIAZm212tT8EFq/hc21vhua1ysESk67e5UA38qz0uzwLZpBBe+4yh8xt8SRScrV353BoywHETMpJp5nqcZE5b+oe37KKOuV5xawqh45IXx+SxZNxNJ291MS5aV/p6oQhb7E8gMiwa5GA3cnF/3FQ8x4qnSXeCXi5+o3OKzfz3hl7zC8sLKCzZ8ItD0O+AshEbYuBm2S+dC9hVuTqysgsbed5DGIVEYzQiRbBhbqfP8gPPA5g/u4gL9OPzevL8EBvfmFDIuyi4hg1ZK/9YPHuBGEFGvvBG/AQSlp+fgUq4Rc9FFFkRLC4SHn7x/iw8zPbXXxJ+bhYAS99ISnk/S1Irj+YCY5VMxPckyu+lLW2vK3Oh5pAqCDfRj9cuCYCu0PqQQ+MH9ziz0PYhCljLsrg1bRvEfU70vNIvfyf+p9wS0DC2y9MD98MIIlV666FjzgwZkSAhhEHTkc4binhwVBVpQvPUUa9mowL1N3+553PPPoxWeN4sRPaA8g+WDd4v5c96b0ILKBnQ7KbVWRPjmBqQtrTGg1ews047nA2JmLVydAt7bTDO76Uu7a8ocJOURXEc/aMaWjvXPQrwHS4OPSqs3lLDRoLf3886HboFSspdX6h4wNlxi902ga8lPxoLmDb+vG9VeW7fETsQGWW8IrZ6OcKPm/uNgLHB3A0EIM+S5TkDZPtm1W04g/faeswPZjbR2JRmhu/UWPNgpDVz3ZH0+AHYzrRUuib7hQXL/d/6KPPrrJ8Vx4OePkdGHPyKv2sm7u9nB7qULzDc4w4HipbqjWOQK/LtJYypggPr67V4cQ1HFVpy7gtD5lSrRemF0WpwdgODCIG7T6kkeGx2YgK6rsxXC2Jmbl8fsr+WEIYw92YWQ5wejZAri4dZxVzdLwNh+R+t1Kei8mFarJ23lREyUQJ6q8F6KtUWe0P0HUMwyVbi7eFkF8frIY7sJLJSHYxN3e+DYfiFsIHQ2oLv5xYPpdr6wAaIIYrYM6PmmVlq85l2RG5Uheoux6GxiZWiFVyC/sLxloHeT4B5hYH7EWmEbcT4/c+nc0crlsWfgDHZXWl1BHdPpiKD7Av/4LBA7pZqB31CrWSsKCCE/uSr/axvD2jMzU2ePwwQFr3TP8/MzMIhuzR+ez9PVUBdXbM2IwyYE0j3mFw7+XFfManwAWlFlFrkEaBt2uUUeGyYqmji6l4j6qTka9m3ybnaCUD344iNk/eY+6RKnpz8km3ZuJWMvwkSgmUtXropzmp1pTXzmbx8lly834sodxs7Wbl2/JG1paIpY2Hc3F4iEbcjr9ZdnLv/up7W562f58dva3LVfhuu3DPCmirulApWFkhcrl86d5uHG+PF2WF5/lnV1beM3YHw4vIkf1uau/re0Kve5yV5pa7XjlWvvxioLv8dpHgbcjL8NlifwdN6W1iY8DAimOz84UGlLlPx6MSBvBLdrrw5uqI9VKpXmh5oT4hnn9weVnIQDWx+nlJoLKkDpCf23qfB0DnA/5hYDzPpdPvemel8ILzdTYblvjJVLMJFRls5NeP4M8fx5A8y1WoXn1bUz6hGu3/wx/nRa0uVxTYJg6v6rs9fOSy9NwvV3j/J792ntQl6dqQfsTZnXU/ib+H0M8XJoGyeEtK1/aLfnrk/y/IMyZf6TpHS4tG79+RItf9aax9C9vPZu4vIWdTYz1b/nrsfuEy0xF8Of2Ebexw8X0KJKu/eZCgz6v/221zKeToB5Bmc1/2zuRiJGX5HLPxARrlKa/pnt3xkpl8gpLmSi0iKwpmymPPcDaW0BmvhyRlS0yIRjA9vDaq450hFjI7zbKa0xYEBfGlMDyzSgtXNj6typ2YvnuIhNTOvrmXwQA83ucS6Y5o/lnwrsXGEND0tF5PIFG3DfXHyM3Vd4Dss9dgbli5c/XoZ4a5J349rJawfW1hnkQTnodY1FwnITZ/cSUcUsFVt2+pXTP/v0dmmyk3bvM5Vnn0tsfeYNChQczVYNRzUDeF13j8NbVspYjSoshFy8eFusT7Izfu3iubPSHKexFs1aSW/eDEDMYr+hO6rCGi/I0PhRvf0yP9uh9q5mFnC9WbsVSi6DsPc2eN4nVZRSndhnLh1dU5VKWLWOxXEh6cgYoS9caE84xwpzAP4sGGXWNMT4mQHxR16tei9PyCxmffe6W2VI2GdrOb5Hlr3PENsOGzmjigxWflWkTIKFbnGBaoHhynkUlrh/SptvCOjwimAWMozDNl4TB/wK/1euTExBwWs5KhduwHUTYjzK0BXKCnRNo9tz7VcuxgYX6/b1TKKieIzDsMAsNjC+aWuttgCibGm9BiRaPjGDliV/vtLWUZLWnpmgETvlnceczGJ2/Td+Y41X429XWMmy1TYAu9Om/X5ABnSRUcVLdUezKmSq3xYiUroojYAaF+AMG1DjDp+Yph6XDfDrTAeAmTfoEsE6IFhVvnFox+P9W7c/BSu1c56BtHZpUwGDyY7uZYmSMz7p2H4buPP8+JbvwQMY78UmlksCpc4ucq4krD1rwaMLr5NZzM6fOidNbn7/Uz9/QJbuZtKGjjliqvAu4cBrTgJWd3WlIA5fUQK80lTAe29JQ4gX7GzKhQtEa7oawqewDorV81woYGmIdRq9DRizd43zpM6CXYlLI5Zg6QS1D3p3HHivUhqXBNkKTH6+0ILz7MKrZBazsZfOkD/+wn1fv3r6dTIzaf7zg2UdOlm7mzAb+sjD6ddopsQkKigcqqCZ/NlhvMOSL2nSB7/qbxBA6+tGteeQeB+PC1cnRMtGgrjnBozTiEW0Dgam8+s+r0RyHuT3JVmkGHMujrWRWcyAnxx8iYydMLcE3/jmz7iYme979OFd5O9OPmpch5a1u3n0u4dbNnTMGV10dNFQRSGdoOVLiziZ4R2luB9hH9jyof3Q+lpKAVsuYBGtsrC3YClgzN3qyNC9RFQxSyj8rczPVMmrh35MXvjYMfL6N08J8YLzc9u/R8583zyG290fkvu+fr84P3Dsc9I1TtbuprqhY86o4oRmPb9QHPTratgspHkumL5Hms0WYdPvwNYdewiNEtd/icFsXugiVhezn2Kx7yqlK6hbJwlcrQOYqIA8aPdgLFq2dUVLDS9f7mUyGbuXSOZFsyo1LmqX/ucP5A+/mBDnxVrL+sEmf/GPnyIjf/kBYe7/00EuiLfJFA+jUpm5SS5fvkI+8zfpZio/9ucfFa26C/8Xj68t4otmbUIFdnRTzXCd56tz0eyYjB/DxJALDm1rkd7SFiyK9OThXjC5uPhLWKjJTY10R0bCcKHkWrgIYwonB8PqqUt/fPcNnu7Y/Nz1SUg/XL9pJ7/WWkgprdZmr7b8qzkXuzIG+eEljs54VKCS2H/XYPf6zdX5uavGd+vC9Zt38RwyhKWLM5fPPgf50NZhWOiK9PTdBa/3tCy25UzzsF6tF1cZ4HF4CUc7i2YR8R5muex877ZcIidvXP194zmM7AnL/e//h2jjvedJxa87rLbMmv/QnQK6lbsei7/Bcd/X9hq7m7D7RZovOyHQ3ewwUPkhr2LC4cA3XzPkv+gqAnhW7yVVun3zPdt4oW99EABvQVQaiyrHTeMsjCS8pbCcNP7tYQmGdYBXvnxvEbvIGG4pFryuqa4+7A7jANYWqptYlurlvVCugqjkPRje1phZWh462bopo6u7CV92Svsy+s4Pj3p/TDgDKBaqiIEYmA4/kicAkuKC6/q9AEnxIsJfKbIvEVhgZeu6L1ghv5Ir3QKrnRDdRcfiS9dkQEQcH7hlLLlVKIEuFswMtxyN9z5TwUvMqhK5xPcu+R9Of89cs5XYNbKH+49Eq4c/m21d7+N2D0DMoDA3Cr5lYV8efMTx+hO89nTf1+6XtvfIuveZz8eEvSkFkCcmQdHddPEwhekUuoB5pC1adXi4YZH622K/s+RYmLrcwGs6t65MCDGS41/WbhVMBphaWjd7F86IBbYmeAUV40AJiD264E2Extq3+OHAlq5Y46Ztn7NSEfdJqTuPeMu52eIf2TPIolLMPysF+6DbKa1WQMz8CnQbQDcSupMu4PomwytSWfY+69DaM73y5yNe6jcB2kO9L/3eXCT6LZcjdc81kY5Yh7blQ85tcZYV3jXWX9MRrxVBt9NOayHllYy3PF1vJDRaXAZxkQuN94q1eSb4vbhm7igL7GNFPT0HocUDAgwHvLqVpZXXaVhvj3uzRXg3Vplo4X+O0L2M+ecFLoRup7RawW5mmsKfmt281RXy7mQSn37+YdHt1Mmy9xmsPWt3Nw4HUKHxaI94NzOtEAEYBsOlvaeG/6hkreSy1XIQKia0MjYObd8n1qH5zHwuF9TQy0hehd7ckkYFRNDaOgOghRWGhxpvRYweAHEDs8gj97uhzgH4gNbtXVwQiCCA8STYOfcg7GBLyvEWzXIDAp+wh1zs3djue/aMEhqYyxR0O0f2OMcoUcwaBTrnF4YBWFM2esCvzEM3NM/u5rPHjrS99myh7vh35Dkmz9mJt8zArIuRTxpqmEz3VFk3N+assI0ZVdHK4N233at1cBomMRixL4cwTgY0WmcnpM1K460IBrOHiW9IwD0kradaZCx5tfxKxrWXP6C9GzvfDXu42Ye6ygmTAbEJgIBErsKcGlxTlgZTVxPI0t3UPyachbvCWZfA68IDtC9wcUxp6ECaPv7sJHenrASErqq1UjPhvHMHVNNkgHgVBzZbzAPeItnI70HarMB4HfiV1lUFtOJF69FO6yr/idPVKKhb8wW6n6U/2WNtfcbEjP/j5ipmPnue6fz8yR9LUytZupvqx4SzoH7WLQEUsXSi4p7NTBMXClpmURPdqZQLYAPuP6reFp+HWzVw4XbtgGqbDJAtKefuuh6MD/bWjnu9SsT9wGxsQot5xQHdS37P3t3LGBOnYcdk+zhiEEB30ygqcTFzTUOnxGfQX8f1LifQzuxmFlJWbBCRPFtlWeID/xgmvajxyjPTU4XK6rUgE9YG3YCtouEftoMz4Z3g+uXz0Ap1deOMhVe00Brdo3Rb2oBf2JX20tn3Zu48gNlYWq0db1NAlxbHXv5CmBO2XqqXyCleiI15xAt1aFt7FqsssGaoBAOJOQDfAEjTKpu5ME1euM/v60pZPiR8+JtHyLMpu6m8/z42c2nsRW6EfPIRB7O/4eFwoLoBxlL4s+QSqY6Tzc9OWL5UDn4aH+KlfVsbThqtYUUYPPPWxYj4EriBwXVzY65KBf+uQW/PbrF5IFO6C41x1fFB3opTwvO0tm8jUVl8SR0plxerxq95wyzfrfXmFeXKl7QTccSzQOamcFmGDTED2b3eOqiclEcA1JkuRra15BOH0fpUidJpfm1MiGCbyNbiNkaiIUrE5poCbq9COryVDJt1xvJbhLGUgcqVd7z+tJz5pD8v17MFtK/SW2kM9rsEZAy6pdIsiImZuJHGVi9tAWvK7v9OuuVHP3rohcRdOFTeePUk2bnTnmc60Kr75Kf2p/qCEy+Er8jp/aZAyDNiFq+lB+/NRNr7Wym/qaAgFbFuJnQz0o6Z6JheWUoCdt5II2QAvIyeBpjVPJLyVad61OyG2Cp3npXeFZfpmupmE7IsJP2mPNMqKMiNuJhxeAeorZkpWFOWtnsJY2Vp+c07Y+TwN45Imx+wxbb3ZABj07eujunC7qroWSo5xmeLF92T4k4K70NSGnAdDogzy28tKOgoLWLm+vhCEmnWlCGwbZBr0N9Flr3PvNeeRdFpafIljXAgJlGAeDAuFA8EzXpaqj8445GEmn6SfzVOn7gLCpYU4z8srGCGhX/SeucBM0e16g8sA/PtAkJgzHdO0jUgKWwhNAV3JC0tM0EbG6StCSg90wEhA5FBoTEJju6m2k3+EbgGR55CZhNME2n8FhR0DHVzxiawaV/YtwmM1mnrNQtvlVUun4PlGL6oQqJXbP2aeuj+dXf9mnpWMbnp+PgpKFjVmFtmHI8dBtYmjReRQVB0bG660ICb7heuqe5qOEQPA6huehyIKS4dU9wFBWsKY8tMUKksltb1jQe0tJOat+5di8Cn+mEhoSpMqlDoooECY3MHVD82/+imn9GfbvfB5DdN+IKCVYVdzDgLtyqz4bq7ZnlrxX916ioFdjGYuXTuv7hRrfC62SRENjucVTOghzeJlMkMZ/CrovorKLjjsXYzEfly7ZqeEICXpfu7br8srbpoILq7zR8C1/FwoV5XxQvNpvAmcWsHmzDa3AsKVhzOlhlSm7s2voYnBMb7uub+c3Jy8jY3q5VXNYNwgB3d0I7odkC1oxnOql84q/500C+cdVzhCgruOFJVCHipNojIftemc6uJxq4P78D2NSgYpvxAIUmTV2pcuhDZ4jGlr4ftBJCmKR2be0HBisSrZYbMz167Gpb73ialEuwAsWoFDbYhYSx4tXLpf6H7jAJiExnXdZMAAeiG1/EA4KyLBF5X4zMJCV7zIY3fgoJVT9oCjxUOPx+VtJvkyoOxMxu6b71i6FYCqpi4QKHB/EiTj3pYFdXNdD0trjjyiL+gYMUABTozjX2OuuHjsStf1GDDQUreqlw6BzthqIIBgF2t3Gq+qNd0d8B0TQf9AuhPd1PtJkx+fMKppPVfULBqwIrVNmJjxzoZZQEdoows+xeuoStJCZ2KWH1soLv6lrL9NVRm/N1YsbGS++YH+tXj0sPr/uAMqGFWGup9FhSsGvTKlwvwdZvpajhUD1hI69FgQEuN8TUW/x5eE59WneVthCAgVfh2ARetasC6qyRYrJBqdbpSuXCDX9Yrpqui2vJCFyCdPCq+676ApOsFBQV3EChG+hlQ3UyHSpJ9qXClu1z3VFBQ0EGyVGwMo5/XIoXwFRRYWK2VI8/7Xi0iWAhZwRqBkP8HZKlNbT9wPrcAAAAASUVORK5CYII=",Do=({currentMode:t,enabledModes:e,onModeChange:r,onScreenAccessRequest:o})=>{const n=i=>{switch(i){case"show":return d.jsx(oe,{className:"w-4 h-4"});case"tell":return d.jsx(De,{className:"w-4 h-4"});case"do":return d.jsx(zt,{className:"w-4 h-4"});default:return null}},s=["tell","show","do"].filter(i=>e.includes(i));return d.jsxs("div",{className:`
        px-3 pb-2
        bg-transparent flex items-center justify-between
      `,children:[d.jsx("div",{className:"flex space-x-2",children:s.map(i=>d.jsxs("button",{onClick:a=>{a.preventDefault(),a.stopPropagation(),r(i),(i==="show"||i==="do")&&o&&o(i)},className:`
                flex items-center justify-center gap-1 text-sm font-medium transition-all duration-200
                ${t===i?"bg-purple-600 text-white shadow-lg":"bg-purple-100 text-black hover:bg-purple-200 border border-purple-200"}
              `,style:{width:"65px",height:"26px",borderRadius:"22px",opacity:1},title:No(i),children:[n(i),d.jsx("span",{className:"text-xs font-medium",children:To(i)})]},i))}),d.jsx("img",{src:Mo,alt:"Marketrix Logo",className:"w-18 h-5 object-cover"})]})},Fo=({messages:t,isLoading:e,messagesEndRef:r,onSendMessage:o,onSetMode:n,config:s})=>{const{getWidgetText:i,getActiveAvatar:a}=re(s),p=i(),c=a(),u=[{id:"show-add-product",text:"Show me how to add a new product",icon:d.jsx(oe,{className:"w-6 h-6"}),type:"show",isShow:!0},{id:"show-login",text:"Show me how to login",icon:d.jsx(oe,{className:"w-6 h-6"}),type:"show",isShow:!0},{id:"show-revenue",text:"Show me the revenue metrics",icon:d.jsx(oe,{className:"w-6 h-6"}),type:"show",isShow:!0},{id:"tell-conversion-rate",text:"What does my conversion rate mean and how can I improve it?",icon:d.jsx(De,{className:"w-5 h-5"}),type:"tell",isShow:!1}],f=(x,m)=>{m.preventDefault(),m.stopPropagation(),n&&x.type&&(console.log("Setting mode to:",x.type),n(x.type)),o&&(console.log("Sending message with mode:",x.type,x.text),o(x.text,x.type))},y=()=>{const x=[];return t.length===0&&!e&&x.push(d.jsx("div",{className:"space-y-3",children:d.jsx("div",{className:"flex justify-start",children:d.jsxs("div",{className:"w-full ",children:[d.jsxs("div",{className:"flex gap-2",children:[d.jsx("img",{src:Pt,alt:"Marketrix Logo",className:"w-6 h-6 object-cover"}),d.jsx("div",{className:" font-inter font-normal text-sm bg-white text-black px-3 py-2 gradient-border",children:p.greeting||"Hey! 👋 I'm Marketrix AI, How can I help you"})]}),d.jsxs("div",{className:"flex items-center justify-between mt-1.5 text-sm font-medium text-[#1D2939]",children:[d.jsx("span",{children:c.name||"Marketrix AI"}),d.jsxs("span",{className:"text-[#667085] text-xs font-normal",children:[new Date().toLocaleDateString("en-US",{weekday:"long"})," ",new Date().toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit"})]})]})]})})},"welcome-message")),e||x.push(d.jsx("div",{className:"space-y-2",children:u.map(m=>d.jsx("div",{className:"flex justify-start",children:d.jsx("button",{onClick:b=>f(m,b),className:`
                  w-full font-inter font-normal text-sm px-3 py-2 rounded-lg cursor-pointer transition-all duration-200 text-left hover:shadow-md
                  ${m.isShow,"bg-white border border-gray-200 hover:bg-gray-50"}
                `,children:d.jsxs("div",{className:"text-sm text-black flex items-center space-x-2",children:[d.jsx("span",{className:"text-black",children:m.icon}),d.jsx("span",{className:"font-normal",children:m.type==="show"?d.jsxs(d.Fragment,{children:[d.jsx("span",{className:"font-bold",children:"Show me"}),m.text.replace("Show me","")]}):m.text})]})})},m.id))},"suggested-actions")),t.forEach(m=>{x.push(d.jsxs("div",{className:`flex flex-col gap-1 ${m.sender==="user"?"justify-end":"justify-start"}`,children:[d.jsxs("div",{className:`flex flex-col gap-2 justify-between
              w-full px-3 py-3 rounded-l-md rounded-b-md shadow-sm border
              ${m.sender==="user"?"bg-[#101828] text-white":"bg-white text-black border-gray-200"}
            `,children:[m.sender==="user"&&m.mode&&d.jsxs("span",{className:"inline-flex items-center gap-1 px-2 py-0.5 bg-[#6941C6] text-white text-xs font-medium rounded-2xl w-fit",children:[m.mode==="show"?d.jsx(oe,{className:"w-3 h-3"}):m.mode==="tell"?d.jsx(De,{className:"w-3 h-3"}):m.mode==="do"?d.jsx(zt,{className:"w-3 h-3"}):null,m.mode==="show"?"Show":m.mode==="tell"?"Tell":m.mode==="do"?"Do":m.mode]}),d.jsx("div",{className:"text-sm font-inter font-normal whitespace-pre-wrap break-words",children:m.content})]}),d.jsxs("div",{className:"flex items-center justify-between text-xs font-inter font-normal",children:[d.jsx("div",{className:"items-center gap-2",children:d.jsx("span",{children:m.sender==="user"?"You":c.name||"Marketrix AI"})}),d.jsx("span",{children:Io(m.timestamp)})]})]},m.id))}),e&&x.push(d.jsx("div",{className:"flex justify-start",children:d.jsx("div",{className:"w-full px-3 py-2 rounded-2xl bg-white shadow-sm border border-gray-200",children:d.jsxs("div",{className:"flex items-center space-x-2",children:[d.jsxs("div",{className:"flex space-x-1",children:[d.jsx("div",{className:"w-2 h-2 bg-gradient-to-r from-green-400 to-purple-500 rounded-full animate-bounce"},"dot-1"),d.jsx("div",{className:"w-2 h-2 bg-gradient-to-r from-green-400 to-purple-500 rounded-full animate-bounce",style:{animationDelay:"0.1s"}},"dot-2"),d.jsx("div",{className:"w-2 h-2 bg-gradient-to-r from-green-400 to-purple-500 rounded-full animate-bounce",style:{animationDelay:"0.2s"}},"dot-3")]}),d.jsx("span",{className:"text-xs text-gray-500",children:"Typing..."})]})})},"loading-indicator")),x.push(d.jsx("div",{ref:r},"scroll-anchor")),x};return d.jsx("div",{className:`
        h-full overflow-y-auto px-4 space-y-3
        bg-transparent
        scrollbar-thin scrollbar-track-[#f6f6f6] scrollbar-thumb-[#b6b6b6]
      `,style:{scrollbarColor:"#f6f6f6 transparent",scrollbarWidth:"thin",marginRight:"12px"},children:y()})},qo="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAABBCAYAAABo3gIBAAAACXBIWXMAACxLAAAsSwGlPZapAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAQySURBVHgB3Zs/ctpAFMbfSkiIifCQImOVKlOSLiVlSt/AvkF8A4cTxDmBzQmcG5gyHXaZCtyRKmRMYmGQNm8V5IksIUvalXbFrzCDVh7Ex3v7vv2nwwv0EPzr2HYLPAT2HG1XQ8t2Bu2uc/3gWz+pAVP2yt4bXecE9hiSdtE6cM4ohU8Z/zcLAIbr+/kl7BkJQVgEYNhcQD5CYfQ1jD1vPoM9ICEIpsUUX1woxowSuNQeYdR0YWKCWNhv4Be7Bg4ooDBrGDZVmFinSintAyeo8AnrhM2uc2FZjgsNQ4OKaKowMUEIITcgmEgYVrJZKQfFEdWpFmGMlWmkaslOCCKiY82Jkl5Gf35h87ic6e1uH5V6C9XSw884arXtE61t/woel8LTtQypTpUNYEy/PSVAelAfSpg8PfUqDuJMw15RQj5AfYQRg090pFt2zyD23WazXEDNkKxGVhnwZQCSkGHyMgWxeo4b+HRSc+okqFMYPatx4y0XhtntoGwDkAj+an180lO9bbuGZt9WmUokz03mweGEUMJt6wUy9ikMN8v5GASj57nJMLrfUboTUAdXw+fBkj3Akk1EluxcgjBv0jK7r1GU96AWrmgvkytlQtCbtH1rAtXael643W9+QaBWW89LaZOXK2UiwtTBvAW1o4RR2uQVihCGKt6kKHm9TKEIYTBvIsHWc5PXyxSOkAjZtp6XXRFTWhDj1Zu+pukTaD4xk1c4ZSKC9Z+5YdpEtq0XwJPJI6Z9VzpCQprhTQrBJwgkvQkFusCwySxxuNyRfg8JhXVBItyCiKbz6vA00MhnkETpPqQqNuvf32T2TZUtVPGgU/8rSEJJQXyiS3PBSgoSEDgGSbRAIdj2LS+wPlIqbzKKv+x2neMgw8IToBj+GQNBgm2Uhu1YsnuyB41cgjR15JvBjKsPCXw42wcxQjOJ45mO7r0rP7grthdNSZgQGiVfrJZ3vkDYtVKCsFShfmjXXWgmM/ziQy9l7rVUlfmXKg0Ug8I4FCJjPadwhDRyHiSHEBGFIwTFuIKmUECIiEKCbHc4u6A44fQghZFXYqkzd8psO9IpKMq2dI7Ihpzz7BLIHSFBQK+IetMnT6Wz01o9lU4ecgnCPAeqr9Lqf0IIUedWXvzJVfMcaWZKJC9GiEKeIzRTq/sfl+xNVSeZMgUJUwUk7wspUTp52JkybG7iQeYSQ81CROyMkIegc4ZP5ULdSBIiIv2ImQTPwWOmRJIaIduqUjn/m6mVIgeOEoLUYc9FmymRxFOm4rXaqj2ECGIRYvrmACoQoypXWQXxlKFaX/BwpRYzJZKYIARX5XFZALiRXDp5iAtCyA0FDhosRETambvie8f2QIiI5FF3nDMlmnadZ71FFTMlktQOYzuRzOZO3edtomamVGVnD8rsO/gwQJN2zLY6UUpuNKC3KnsIEfwFUvIjIsujwzAAAAAASUVORK5CYII=",Y=class Y{constructor(){j(this,"currentHighlight",null);j(this,"spotlightOverlay",null)}static getInstance(){return Y.instance||(Y.instance=new Y),Y.instance}highlightElement(e){const{element:r,duration:o=3e3,spotlightColor:n="rgba(255, 255, 0, 0.3)",borderColor:s="#ffd700",borderWidth:i=3,borderRadius:a=8,zIndex:p=9999}=e;this.clearHighlight(),this.currentHighlight=r;const c=r.getBoundingClientRect(),u=window.pageXOffset||document.documentElement.scrollLeft,f=window.pageYOffset||document.documentElement.scrollTop;this.createSpotlightOverlay({x:c.left+u,y:c.top+f,width:c.width,height:c.height,spotlightColor:n,borderColor:s,borderWidth:i,borderRadius:a,zIndex:p}),r.classList.add("marketrix-highlighted"),r.style.position="relative",r.style.zIndex=(p+1).toString(),r.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),setTimeout(()=>{this.clearHighlight()},o)}createSpotlightOverlay(e){const{x:r,y:o,width:n,height:s,spotlightColor:i,borderColor:a,borderWidth:p,borderRadius:c,zIndex:u}=e,f=document.createElement("div");f.id="marketrix-spotlight-overlay",f.style.position="fixed",f.style.top="0",f.style.left="0",f.style.width="100%",f.style.height="100%",f.style.zIndex=u.toString(),f.style.pointerEvents="none",f.style.background=`radial-gradient(ellipse at center, transparent 0%, transparent 40%, ${i} 100%)`,f.style.mask=`
      radial-gradient(
        ellipse ${n+40}px ${s+40}px at ${r+n/2}px ${o+s/2}px,
        transparent 0%,
        transparent 40%,
        black 100%
      )
    `,f.style.webkitMask=f.style.mask;const y=document.createElement("div");y.style.position="absolute",y.style.left=`${r-p}px`,y.style.top=`${o-p}px`,y.style.width=`${n+p*2}px`,y.style.height=`${s+p*2}px`,y.style.border=`${p}px solid ${a}`,y.style.borderRadius=`${c}px`,y.style.boxShadow=`0 0 20px ${a}`,y.style.animation="marketrix-pulse 2s infinite",this.addPulseAnimation(),f.appendChild(y),document.body.appendChild(f),this.spotlightOverlay=f}addPulseAnimation(){if(document.getElementById("marketrix-pulse-animation"))return;const e=document.createElement("style");e.id="marketrix-pulse-animation",e.textContent=`
      @keyframes marketrix-pulse {
        0%, 100% { 
          opacity: 1; 
          transform: scale(1);
        }
        50% { 
          opacity: 0.7; 
          transform: scale(1.05);
        }
      }
      
      .marketrix-highlighted {
        animation: marketrix-pulse 2s infinite;
      }
    `,document.head.appendChild(e)}clearHighlight(){this.currentHighlight&&(this.currentHighlight.classList.remove("marketrix-highlighted"),this.currentHighlight.style.position="",this.currentHighlight.style.zIndex="",this.currentHighlight=null),this.spotlightOverlay&&(document.body.removeChild(this.spotlightOverlay),this.spotlightOverlay=null)}highlightBySelector(e,r){const o=document.querySelector(e);return o?(this.highlightElement({element:o,...r}),!0):!1}highlightByText(e,r){var n;const o=document.querySelectorAll("h1, h2, h3, h4, h5, h6, p, span, div");for(const s of o)if((n=s.textContent)!=null&&n.includes(e))return this.highlightElement({element:s,...r}),!0;return!1}};j(Y,"instance");let Fe=Y;const ne=Fe.getInstance(),Wo=({isOpen:t,onAllow:e,onDeny:r,onClose:o})=>t?d.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999]",onClick:n=>{n.target===n.currentTarget&&o()},children:d.jsx("div",{className:"bg-white rounded-lg p-3 max-w-md mx-4 shadow-xl",children:d.jsxs("div",{className:"text-center",children:[d.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-3",children:"Can I take a look at your screen?"}),d.jsx("p",{className:"text-gray-600 mb-6 text-sm leading-relaxed",children:"By allowing screen access, Marketrix can understand your current context to guide you better and complete tasks on your behalf."}),d.jsxs("div",{className:"flex gap-3 justify-center",children:[d.jsx("button",{onClick:n=>{n.preventDefault(),n.stopPropagation(),e()},className:"px-5 py-1 bg-[#E7DDFF] text-[#6941C6] rounded-full transition-all duration-200 text-sm font-medium",children:"Yes"}),d.jsx("button",{onClick:n=>{n.preventDefault(),n.stopPropagation(),r()},className:"px-6  py-1 bg-[#E7DDFF] text-[#6941C6] rounded-full hover:bg-gray-50 transition-all duration-200 text-sm font-medium",children:"No"})]})]})})}):null,Uo=({value:t,onChange:e,onKeyPress:r,onSend:o,isLoading:n,config:s,onScreenAccessResponse:i,triggerScreenAccessModal:a=!1,onTriggerReset:p})=>{const[c,u]=g.useState(!1),{getWidgetText:f}=re(s),y=f();g.useEffect(()=>{a&&u(!0)},[a]);const x=()=>{m(t),o()},m=w=>{const v=w.toLowerCase();(v.includes("highlight")||v.includes("show me")||v.includes("point to"))&&(v.includes("h1")||v.includes("title")||v.includes("heading")?ne.highlightBySelector("h1",{duration:5e3,spotlightColor:"rgba(255, 255, 0, 0.4)",borderColor:"#ffd700",borderWidth:4}):v.includes("h2")?ne.highlightBySelector("h2",{duration:5e3,spotlightColor:"rgba(0, 255, 255, 0.4)",borderColor:"#00ffff",borderWidth:4}):v.includes("button")?ne.highlightBySelector("button",{duration:5e3,spotlightColor:"rgba(0, 255, 0, 0.4)",borderColor:"#00ff00",borderWidth:4}):(v.includes("demo")||v.includes("widget"))&&ne.highlightByText("Marketrix In-App Support Widget Demo",{duration:5e3,spotlightColor:"rgba(255, 0, 255, 0.4)",borderColor:"#ff00ff",borderWidth:4})),v.includes("marketrix")&&v.includes("demo")&&ne.highlightByText("Marketrix In-App Support Widget Demo",{duration:5e3,spotlightColor:"rgba(255, 255, 0, 0.4)",borderColor:"#ffd700",borderWidth:4})},b=w=>{w.key==="Enter"&&!w.shiftKey?(w.preventDefault(),x()):r(w)},h=w=>{u(!1),w?i==null||i(!0):i==null||i(!1)},k=()=>{u(!1),p==null||p()};return g.useEffect(()=>{c&&a&&(p==null||p())},[c,a,p]),d.jsxs("div",{className:`
      py-2 pr-2
      bg-transparent
      `,children:[d.jsxs("div",{className:"flex items-center space-x-2",children:[d.jsx("div",{className:"flex-1 relative",children:d.jsx("textarea",{value:t,onChange:w=>e(w.target.value),onKeyPress:b,placeholder:y.placeholder||"Show me..",disabled:n,rows:1,className:`
              w-full px-3 py-2 text-sm resize-none
              focus:outline-none
              disabled:opacity-50 disabled:cursor-not-allowed
              bg-white border-gray-200 text-gray-900 placeholder-gray-400
              shadow-sm
            `,style:{minHeight:"40px",maxHeight:"120px"}})}),d.jsx("button",{onClick:w=>{w.preventDefault(),w.stopPropagation(),x()},disabled:!t.trim()||n,className:`
            w-8 h-8 rounded-full transition-all duration-200 flex items-center justify-center
            ${t.trim()&&!n?"bg-gradient-to-r from-[#B398F6] to-[#5CF2B5] text-white shadow-lg":"bg-gray-200 text-gray-400 cursor-not-allowed"}
            focus:outline-none focus:ring-2 focus:ring-green-500/20
          `,"aria-label":"Send message",children:d.jsx("img",{src:qo,alt:"Send",className:"w-4 h-4"})})]}),d.jsx(Wo,{isOpen:c,onAllow:()=>h(!0),onDeny:()=>h(!1),onClose:k})]})},Ho=({stream:t,isVisible:e,onClose:r})=>{const o=g.useRef(null);return g.useEffect(()=>{o.current&&t&&(o.current.srcObject=t)},[t]),!e||!t?null:d.jsx("div",{className:"fixed top-4 right-4 w-80 h-60 bg-black rounded-lg shadow-xl border border-gray-300 overflow-hidden z-50",children:d.jsxs("div",{className:"relative w-full h-full",children:[d.jsx("video",{ref:o,autoPlay:!0,muted:!0,className:"w-full h-full object-cover"}),d.jsx("button",{onClick:r,className:"absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600 transition-colors","aria-label":"Close screen preview",children:"×"})]})})},Xo=({config:t,isOpen:e,isMinimized:r,isLoading:o,messages:n,currentMode:s,onClose:i,onSendMessage:a,onSetMode:p,onScreenSharingChange:c})=>{var Dt,Ft,qt,Wt,Ut,Ht;const[u,f]=g.useState(""),[y,x]=g.useState(!1),[m,b]=g.useState(!1),[h,k]=g.useState(null),[w,v]=g.useState(!1),N=g.useRef(null),{getWidgetCustomize:A,getWidgetPosition:P}=re(t),E=A(),q=P();g.useEffect(()=>{var L;(L=N.current)==null||L.scrollIntoView({behavior:"smooth"})},[n]),g.useEffect(()=>()=>{ie()},[]);const C=()=>{u.trim()&&!o&&(a(u,s),f(""))},W=L=>{L.key==="Enter"&&!L.shiftKey&&(L.preventDefault(),C())},Ko=async L=>{L?await Go():console.log("Screen access denied")},Go=async()=>{try{const L=await navigator.mediaDevices.getDisplayMedia({video:{width:{ideal:1920},height:{ideal:1080}},audio:!1}),T=document.createElement("div");T.id="marketrix-screen-status",T.style.position="fixed",T.style.top="20px",T.style.left="20px",T.style.zIndex="9999",T.style.display="flex",T.style.alignItems="center",T.style.gap="8px",T.style.backgroundColor="rgba(255, 255, 255, 0.95)",T.style.padding="8px 16px",T.style.borderRadius="20px",T.style.fontSize="14px",T.style.fontWeight="500",T.style.boxShadow="0 4px 12px rgba(0, 0, 0, 0.15)",T.style.border="1px solid rgba(0, 0, 0, 0.1)",T.innerHTML=`
        <div style="width: 8px; height: 8px; background-color: #ef4444; border-radius: 50%; animation: pulse 2s infinite;"></div>
        Marketrix is monitoring your screen
        <button id="marketrix-stop-btn" style="background: #ef4444; color: white; border: none; padding: 4px 8px; border-radius: 12px; cursor: pointer; font-size: 12px; margin-left: 8px;">Stop</button>
      `;const Xt=document.createElement("style");Xt.textContent=`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `,document.head.appendChild(Xt),document.body.appendChild(T);const Vt=document.getElementById("marketrix-stop-btn");Vt&&(Vt.onclick=()=>{ie(),x(!1)}),L.getVideoTracks()[0].onended=()=>{ie(),x(!1)},window.screenCaptureStream=L,window.screenCaptureOverlay=T,k(L),v(!0),x(!0),c==null||c(!0)}catch(L){console.error("Error accessing screen:",L),x(!1),alert("Unable to access screen. Please check your permissions.")}},ie=()=>{window.screenCaptureStream&&window.screenCaptureStream.getTracks().forEach(T=>{T.stop()});const L=document.getElementById("marketrix-screen-status");L&&document.body.removeChild(L),window.screenCaptureStream=null,window.screenCaptureOverlay=null,k(null),v(!1),c==null||c(!1)},_o=L=>{b(!0)},Jo=()=>{b(!1)};if(!e)return null;const Mt=q.position||t.position||"bottom-right",Qo=Nt(Mt),Zo=Eo(Mt),$o={width:((Dt=E.sizes)==null?void 0:Dt.width)||"320px",height:r?"48px":((Ft=E.sizes)==null?void 0:Ft.height)||"35rem",borderRadius:((qt=E.sizes)==null?void 0:qt.border_radius)||"12px",fontSize:((Wt=E.sizes)==null?void 0:Wt.font_size)||"14px",background:((Ut=E.colors)==null?void 0:Ut.background)||"white",borderColor:((Ht=E.colors)==null?void 0:Ht.border)||"rgba(255, 255, 255, 0.2)",zIndex:q.z_index||40};return d.jsxs("div",{className:`fixed ${Qo}`,style:{zIndex:q.z_index||40,background:"#ffffff90",borderRadius:"12px"},children:[d.jsxs("div",{className:`
          ${Zo} 
          ${r?"h-12":"h-[35rem]"} 
          transition-all duration-300 ease-in-out flex flex-col
          ${e?"animate-slide-up":"animate-slide-down"}
          transform-gpu
          shadow-2xl
          backdrop-blur-sm
          scrollbar-thin scrollbar-track-[#f6f6f6] scrollbar-thumb-[#b6b6b6]
        `,style:{...$o,scrollbarColor:"#f6f6f6 #b6b6b6",scrollbarWidth:"thin"},children:[d.jsx("div",{className:`
          flex justify-end p-2 mb-5
                  `,children:d.jsx("div",{className:"flex items-center space-x-1 bg-white rounded-full p-0.5 absolute top-2 right-2",children:d.jsx("button",{onClick:i,className:"p-1 rounded-full hover:bg-white shadow-sm","aria-label":"Close chat",children:d.jsx("svg",{className:"w-3 h-3 text-black",fill:"currentColor",viewBox:"0 0 20 20",children:d.jsx("path",{fillRule:"evenodd",d:"M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",clipRule:"evenodd"})})})})}),!r&&d.jsxs(d.Fragment,{children:[d.jsx("div",{className:"flex-1 overflow-hidden",children:d.jsx(Fo,{messages:n,isLoading:o,messagesEndRef:N,onSendMessage:a,onSetMode:p,config:t})}),y&&d.jsxs("div",{className:"flex items-center gap-2 px-2 mx-3",children:[d.jsxs("div",{className:"flex items-center gap-2",children:[d.jsx("div",{className:"w-2 h-2 bg-red-500 rounded-full animate-pulse"}),d.jsx("span",{className:"text-xs text-[#667085] font-inter",children:"Marketrix is looking at your screen"})]}),d.jsx("button",{onClick:()=>{ie(),x(!1)},className:"text-xs text-[#667085] font-bold",children:"Stop"})]}),d.jsxs("div",{className:"flex-shrink-0 rounded-lg bg-white m-3",children:[d.jsx(Uo,{value:u,onChange:f,onKeyPress:W,onSend:C,isLoading:o,config:t,onScreenAccessResponse:Ko,triggerScreenAccessModal:m,onTriggerReset:Jo}),d.jsx(Do,{currentMode:s,enabledModes:t.enabledModes||["tell","show","do"],onModeChange:p,onScreenAccessRequest:_o})]})]})]}),d.jsx(Ho,{stream:h,isVisible:w,onClose:()=>{ie(),x(!1)}})]})},Vo=({config:t})=>{var b,h,k,w,v,N,A,P,E;const{state:e,actions:r}=Ao({config:t}),{atmosphereConfig:o,marketrixConfig:n,shouldShow:s,getWidgetCustomize:i,getWidgetPosition:a,isLoading:p}=re(t),[c,u]=g.useState(!1);if(!s)return null;const f=n||t,y=i(),x=a(),m={"--widget-width":((b=y.sizes)==null?void 0:b.width)||"320px","--widget-height":((h=y.sizes)==null?void 0:h.height)||"35rem","--widget-border-radius":((k=y.sizes)==null?void 0:k.border_radius)||"12px","--widget-font-size":((w=y.sizes)==null?void 0:w.font_size)||"14px","--widget-primary-color":((v=y.colors)==null?void 0:v.primary)||"#1BB55B","--widget-secondary-color":((N=y.colors)==null?void 0:N.secondary)||"#987ADD","--widget-background":((A=y.colors)==null?void 0:A.background)||"linear-gradient(135deg, #1BB55B26 0%, #987ADD30 100%)","--widget-text-color":((P=y.colors)==null?void 0:P.text)||"#333333","--widget-border-color":((E=y.colors)==null?void 0:E.border)||"rgba(255, 255, 255, 0.2)","--widget-z-index":x.z_index||40};return d.jsxs("div",{className:"marketrix-widget",style:m,"data-widget-mode":(o==null?void 0:o.widget_mode)||"ai","data-avatar-status":(o==null?void 0:o.avatar_status)||"online","data-streaming-status":(o==null?void 0:o.streaming_avatar_status)||"idle",children:[d.jsx(Co,{config:f,onClick:r.toggleWidget,isOpen:e.isOpen,agentAvailable:e.agentAvailable,isScreenSharing:c}),d.jsx(Xo,{config:f,isOpen:e.isOpen,isMinimized:e.isMinimized,isLoading:e.isLoading||p,messages:e.messages,currentMode:e.currentMode,agentAvailable:e.agentAvailable,onClose:r.closeWidget,onSendMessage:r.sendMessage,onSetMode:r.setMode,onScreenSharingChange:u}),e.error&&d.jsx("div",{className:"fixed top-4 right-4 z-50 max-w-sm",children:d.jsx("div",{className:"bg-red-500 text-white px-4 py-3 rounded-lg shadow-lg",children:d.jsxs("div",{className:"flex items-center justify-between",children:[d.jsx("span",{className:"text-sm",children:e.error}),d.jsx("button",{onClick:r.clearError,className:"ml-4 text-white hover:text-red-100",children:d.jsx("svg",{className:"w-4 h-4",fill:"currentColor",viewBox:"0 0 20 20",children:d.jsx("path",{fillRule:"evenodd",d:"M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",clipRule:"evenodd"})})})]})})})]})};let se=null;const ve=t=>{if(!t.marketrixId||!t.marketrixKey){console.error("Marketrix Widget: marketrixId and marketrixKey are required");return}ke=t;let e=document.getElementById("marketrix-widget-container");e||(e=document.createElement("div"),e.id="marketrix-widget-container",e.className="marketrix-widget-container",document.body.appendChild(e));const r=Xe(e);se=r,r.render(d.jsx(g.StrictMode,{children:d.jsx(Vo,{config:t})})),console.log("Marketrix Widget initialized successfully")},qe=()=>{if(se){se.unmount(),se=null,ke=null;const t=document.getElementById("marketrix-widget-container");t&&t.remove(),console.log("Marketrix Widget destroyed")}},Rt=t=>{if(se){const r={...We(),...t};qe(),ve(r)}};let ke=null;const We=()=>{if(!ke)throw new Error("Widget not initialized");return ke};document.addEventListener("DOMContentLoaded",()=>{var e;console.log("------------------------------ DOMContentLoaded -----------------------------------");const t=document.currentScript;if(t){const r=t.getAttribute("marketrix-id"),o=t.getAttribute("marketrix-key");if(r&&o){const n={marketrixId:r,marketrixKey:o,position:t.getAttribute("data-position")||"bottom-right",theme:t.getAttribute("data-theme")||"light",avatarUrl:t.getAttribute("data-avatar-url")||void 0,agentName:t.getAttribute("data-agent-name")||void 0,enabledModes:((e=t.getAttribute("data-enabled-modes"))==null?void 0:e.split(","))||["show","tell","do"]};ve(n)}}});const Yo={initMarketrixWidget:ve,destroyMarketrixWidget:qe,updateMarketrixConfig:Rt,getCurrentConfig:We};O.default=Yo,O.destroyMarketrixWidget=qe,O.getCurrentConfig=We,O.initMarketrixWidget=ve,O.updateMarketrixConfig=Rt,Object.defineProperties(O,{__esModule:{value:!0},[Symbol.toStringTag]:{value:"Module"}})});
//# sourceMappingURL=marketrix-inapp.umd.cjs.map
