# 🚀 Marketrix Widget Hosting Guide

## 📁 Build Files Ready for Hosting

Your widget has been successfully built and is ready for hosting! Here are the files you need:

### Core Files:
- `index.html` - Main demo page
- `style.css` - Widget styles
- `marketrix-inapp.js` - ES module version
- `marketrix-inapp.umd.cjs` - UMD version (recommended for hosting)
- `meet.iife.js` - Standalone meeting widget

### Source Maps (optional):
- `marketrix-inapp.js.map` - Source map for debugging
- `marketrix-inapp.umd.cjs.map` - UMD source map

## 🌐 Hosting Options

### 1. Static File Hosting (Recommended)
Upload all files from the `dist/` folder to any static file hosting service:

**Popular Options:**
- **Netlify** - Drag and drop the `dist/` folder
- **Vercel** - Connect your GitHub repo or upload files
- **GitHub Pages** - Push to a `gh-pages` branch
- **AWS S3** - Upload to an S3 bucket with static hosting
- **Firebase Hosting** - Use Firebase CLI to deploy

### 2. Traditional Web Server
Upload files to any web server (Apache, Nginx, IIS):

```
your-domain.com/
├── index.html
├── style.css
├── marketrix-inapp.umd.cjs
└── meet.iife.js
```

### 3. CDN Hosting
Upload to a CDN for better performance:
- **Cloudflare** - Free tier available
- **AWS CloudFront** - With S3 backend
- **KeyCDN** - Fast global delivery

## 🔧 Integration Methods

### Method 1: Direct HTML Integration
```html
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="./style.css">
</head>
<body>
    <!-- Your content -->
    
    <!-- Widget Script -->
    <script src="./marketrix-inapp.umd.cjs"></script>
    <script>
        const widget = new MarketrixInApp({
            apiUrl: 'https://your-api.com',
            widgetId: 'your-widget-id',
            widgetKey: 'your-widget-key'
        });
    </script>
</body>
</html>
```

### Method 2: ES Module Integration
```html
<script type="module">
    import MarketrixInApp from './marketrix-inapp.js';
    
    const widget = new MarketrixInApp({
        apiUrl: 'https://your-api.com',
        widgetId: 'your-widget-id',
        widgetKey: 'your-widget-key'
    });
</script>
```

### Method 3: NPM Package Integration
```bash
npm install @marketrix/inapp-react
```

```javascript
import MarketrixInApp from '@marketrix/inapp-react';

const widget = new MarketrixInApp({
    apiUrl: 'https://your-api.com',
    widgetId: 'your-widget-id',
    widgetKey: 'your-widget-key'
});
```

## ⚙️ Configuration Options

```javascript
const widget = new MarketrixInApp({
    // Required
    apiUrl: 'https://your-api.com',
    widgetId: 'your-widget-id',
    widgetKey: 'your-widget-key',
    
    // Optional
    theme: 'light', // 'light', 'dark', 'auto'
    position: 'bottom-right', // 'bottom-right', 'bottom-left', 'top-right', 'top-left'
    size: 'medium', // 'small', 'medium', 'large'
    autoInit: true, // Auto-initialize on load
    debug: false, // Enable debug logging
    customStyles: {}, // Custom CSS overrides
    onReady: () => console.log('Widget ready'),
    onError: (error) => console.error('Widget error:', error)
});
```

## 🔒 Security Considerations

1. **HTTPS Required**: Always serve over HTTPS in production
2. **CORS Configuration**: Ensure your API server allows requests from your domain
3. **API Keys**: Keep your widget keys secure and rotate them regularly
4. **Content Security Policy**: Configure CSP headers if needed

## 📊 Performance Optimization

1. **Gzip Compression**: Enable gzip on your server
2. **CDN**: Use a CDN for faster global delivery
3. **Caching**: Set appropriate cache headers
4. **Minification**: Files are already minified for production

## 🐛 Troubleshooting

### Common Issues:

1. **Widget not loading**: Check console for errors, verify file paths
2. **API connection failed**: Check CORS settings and API URL
3. **Styling issues**: Ensure CSS file is loaded before JavaScript
4. **Module errors**: Use the correct script type (module vs regular)

### Debug Mode:
```javascript
const widget = new MarketrixInApp({
    // ... other config
    debug: true // Enable debug logging
});
```

## 📞 Support

If you encounter any issues:
1. Check the browser console for errors
2. Verify all files are uploaded correctly
3. Test with the demo page first
4. Contact support with specific error messages

## 🎉 You're Ready!

Your Marketrix widget is now ready for production hosting. Simply upload the `dist/` folder contents to your chosen hosting platform and start providing amazing support experiences to your users!
